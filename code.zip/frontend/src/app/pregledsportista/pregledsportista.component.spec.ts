import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PregledsportistaComponent } from './pregledsportista.component';

describe('PregledsportistaComponent', () => {
  let component: PregledsportistaComponent;
  let fixture: ComponentFixture<PregledsportistaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PregledsportistaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PregledsportistaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DelegatService {

  constructor(private http: HttpClient) { }

  url='http://localhost:4000'

  dohvatiSebe(username){
    const data={
      korisnicko_ime:username
    }
    return this.http.post(`${this.url}/delegat/dohvatiSebe`, data)
  }

  dohvatiTakmicenje(sport, disciplina, pol){
    const data={
      sport:sport,
      disciplina:disciplina,
      pol:pol
    }
    return this.http.post(`${this.url}/delegat/dohvatiTakmicenje`, data)
  }

  upisiSatnicu(datum, vreme, mesto, sport, disciplina, pol){
    const data={
      sport:sport,
      disciplina:disciplina,
      pol:pol,
      datum:datum,
      vreme:vreme,
      mesto:mesto
    }
    return this.http.post(`${this.url}/delegat/upisiSatnicu`, data)
  }

  upisiRezultat(sport, disciplina, pol, rez){
    const data = {
      sport:sport,
      disciplina:disciplina,
      pol:pol,
      rez:rez
    }
    return this.http.post(`${this.url}/delegat/upisiRezultat`, data)
  }

  setRezultat(sport, disciplina, pol, rezultat){
    const data = {
      sport:sport,
      disciplina:disciplina,
      pol:pol,
      rezultat:rezultat
    }
    return this.http.post(`${this.url}/delegat/setRezultat`, data)
  }


  napraviFinale(sport, disciplina, pol, polu){
    const data = {
      sport:sport,
      disciplina:disciplina,
      pol:pol,
      polu:polu
    }
    return this.http.post(`${this.url}/delegat/napraviFinale`, data)
  }
  napraviPolufinale(sport, disciplina, pol, polu){
    const data = {
      sport:sport,
      disciplina:disciplina,
      pol:pol,
      polu:polu
    }
    return this.http.post(`${this.url}/delegat/napraviPolufinale`, data)
  }
  napraviCetvrtfinale(sport, disciplina, pol, polu){
    const data = {
      sport:sport,
      disciplina:disciplina,
      pol:pol,
      polu:polu
    }
    return this.http.post(`${this.url}/delegat/napraviCetvrtfinale`, data)
  }
  napraviOsminafinala(sport, disciplina, pol, polu){
    const data = {
      sport:sport,
      disciplina:disciplina,
      pol:pol,
      polu:polu
    }
    return this.http.post(`${this.url}/delegat/napraviOsminafinala`, data)
  }

  dodeliMedalju(ime, prezime, pol, drzava, sport, disciplina, mesto){
    let m;
    if(mesto==1) m='zlato'
    else if(mesto==2) m='srebro'
    else if(mesto==3) m='bronza'
    const data={
      ime:ime,
      prezime:prezime,
      pol:pol,
      drzava:drzava,
      sport:sport,
      disciplina:disciplina,
      mesto:m
    }
    return this.http.post(`${this.url}/delegat/dodeliMedalju`, data)
  }

  
  
}

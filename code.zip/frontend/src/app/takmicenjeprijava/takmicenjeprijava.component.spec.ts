import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TakmicenjeprijavaComponent } from './takmicenjeprijava.component';

describe('TakmicenjeprijavaComponent', () => {
  let component: TakmicenjeprijavaComponent;
  let fixture: ComponentFixture<TakmicenjeprijavaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TakmicenjeprijavaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TakmicenjeprijavaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

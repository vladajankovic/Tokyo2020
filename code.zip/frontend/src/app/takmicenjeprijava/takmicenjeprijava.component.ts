import { Component, OnInit } from '@angular/core';
import { Delegat } from '../models/delegat';
import { Ekipa } from '../models/ekipa';
import { Korisnik } from '../models/korisnik';
import { Sport } from '../models/sport';
import { Sportista } from '../models/sportista';
import { Takmicenje } from '../models/takmicenje';
import { OrganizatorService } from '../organizator.service';
import { SiteService } from '../site.service';

@Component({
  selector: 'app-takmicenjeprijava',
  templateUrl: './takmicenjeprijava.component.html',
  styleUrls: ['./takmicenjeprijava.component.css']
})
export class TakmicenjeprijavaComponent implements OnInit {

  constructor(private site: SiteService, private userService: OrganizatorService) { }

  ngOnInit(): void {
    this.site.getAllSports().subscribe((s: Sport[]) => {
      this.listaSportova = s.sort((a, b) => {
        if (a.sport > b.sport) return 1;
        else if (a.sport == b.sport) return 0;
        else return -1;
      });
      this.site.getAllSportists().subscribe((s: Sportista[]) => {
        this.listaSportista = s;
        this.userService.getAllTeams().subscribe((e: Ekipa[]) => {
          this.listaEkipa = e;
          this.userService.getAllDelegats().subscribe((d: Delegat[]) => {
            d.forEach(d=>{
              if(d.nadgledanja.length<3) this.listaDelegata.push(d);
            })
          })
        })
      })
    })



  }

  listaSportova: Sport[]=[];
  listaSportista: Sportista[]=[];
  listaEkipa: Ekipa[]=[];
  listaDelegata: Delegat[]=[];
  dostupniSportisti: Sportista[] = [];
  dostupniTimovi: Ekipa[] = [];

  sport_i_disciplina: string = '';
  pol: string = 'muski';
  vrsta: string = '';
  takmicari: string[] = [];
  timovi: string[] = [];
  delegati: string[] =[];
  broj:string='';
  rez:string='';
  runde:number;

  tenis:boolean=false;
  nosioci:string[]=[];
  unesi:boolean=false;


  obrisi() {
    window.location.reload();
  }

  dodeli(){
    if(this.nosioci.length==0) return;
    this.unesi=true;
    console.log(this.nosioci)
    if(this.vrsta=='ekipno') this.timovi=this.nosioci;
    else this.takmicari=this.nosioci;
  }

  odabranSport() {
    this.dostupniSportisti = [];
    this.dostupniTimovi = [];
    this.tenis=false;
    if (this.sport_i_disciplina == '') return;
    let sid = this.sport_i_disciplina.split(',', 2);
    if(sid[0]=='Tenis') this.tenis=true;
    this.userService.proveri(sid[0], sid[1], this.pol).subscribe(p=>{
      if(p['msg']=='ok'){
        this.listaSportova.forEach((s) => {
          if (s.sport == sid[0] && s.disciplina == sid[1]) this.vrsta = s.vrsta;
        })
        if (this.vrsta == 'ekipno') {
          this.listaEkipa.forEach((e) => {
            if (e.sport == sid[0] && e.disciplina == sid[1] && e.pol == this.pol) this.dostupniTimovi.push(e);
          })
        }
        else {
          this.listaSportista.forEach((s) => {
            if (s.sport == sid[0] && s.disciplina == sid[1] && s.pol == this.pol) this.dostupniSportisti.push(s);
          })
        }
      }
      else{
        alert('Takmicenje '+this.sport_i_disciplina+ ' je formirano za '+this.pol+' pol')
      }
    })
    
    
  }

  registruj() {
    if (this.sport_i_disciplina == '' || this.rez=='') { alert('Odaberite Sport!'); return; }
    if (this.takmicari.length == this.timovi.length) { alert('Niste odabrali ucesnike'); return; }
    if(this.delegati.length==0) { alert('Niste odabrali delegata/e'); return; }
    if(this.rez=='' || this.broj=='') return;
    if(this.tenis && !this.unesi) return;
    this.unesi=false;
    if (this.takmicari.length > this.timovi.length) console.log(this.sport_i_disciplina + ' ' + this.pol + ' ' + this.vrsta + ' ' + this.takmicari+' '+this.delegati);
    else console.log(this.sport_i_disciplina + ' ' + this.pol + ' ' + this.vrsta + ' ' + this.timovi+' '+this.delegati);
    let sid = this.sport_i_disciplina.split(',', 2);
    let tmp:any[] = [];
    if(this.takmicari.length>0){
      this.takmicari.forEach(t=>{
        let ipd = t.split(',', 3)
        this.dostupniSportisti.forEach(s=>{
          if(ipd[0] == s.ime && ipd[1]==s.prezime && ipd[2]==s.drzava && this.pol==s.pol){
            tmp.push(s);
          }
        })
      })
    }
    else{
      this.timovi.forEach(t=>{
        this.dostupniTimovi.forEach(d=>{
          if(d.drzava==t) tmp.push(d);
        })
      })
    }
    let tmp2: any[]=[];
    this.delegati.forEach(k=>{
      this.listaDelegata.forEach(d=>{
        if(d.korisnicko_ime==k) tmp2.push(d)
      })
    })
    if(tmp.length>parseInt(this.broj.split(',',2)[0])) alert('Najvise '+this.broj+' takmicara')
    if(this.rez=='poeni') this.runde=6;
    else if(this.rez.split(',', 2)[1]=='CM') this.runde=3;
    else this.runde=1;

    const data = {
      sport:sid[0],
      disciplina:sid[1],
      pol:this.pol,
      datumPocetka:'',
      vremePocetka:'',
      lokacija:'',
      vrsta:this.vrsta,
      takmicari:tmp,
      delegati:tmp2,
      brojUcesnika:this.broj,
      formatRez:this.rez,
      brojRundi:this.runde,
      zavrseno:false,
      grupnafaza:[],
      osminafinala:[],
      cetvrtfinale:[],
      polufinale:[],
      finale:[]
    }
    console.log(data)
    this.userService.registrujTakmicenje(data).subscribe(poruka=>{
      if(poruka['msg']=='postoji') alert('Takmicenje je vec registrovano');
      else if(poruka['msg']=='ok'){
        window.location.reload();
      }
      else{
        alert('Greska')
      }
    })

  }

}

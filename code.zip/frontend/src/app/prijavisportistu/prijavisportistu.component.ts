import { Component, OnInit } from '@angular/core';
import { Ekipa } from '../models/ekipa';
import { Korisnik } from '../models/korisnik';
import { Sport } from '../models/sport';
import { Sportista } from '../models/sportista';
import { SiteService } from '../site.service';
import { VodjaService } from '../vodja.service';

@Component({
  selector: 'app-prijavisportistu',
  templateUrl: './prijavisportistu.component.html',
  styleUrls: ['./prijavisportistu.component.css']
})
export class PrijavisportistuComponent implements OnInit {

  constructor(private userService: VodjaService, private site: SiteService) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem('ulogovan'));
    this.zemlja = this.user.nacionalnost;
    this.ekipa=[];
    this.site.getAllSports().subscribe((s: Sport[]) => {
      this.listaSportova = s;
      for (let i = 0; i < this.listaSportova.length; i++) {
        this.vrsteDisciplina.push(this.listaSportova[i].disciplina);
        let flag = false;
        for (let j = 0; j < this.vrsteSportova.length; j++) {
          if (this.listaSportova[i].sport == this.vrsteSportova[j]) flag = true;
        }
        if (!flag) this.vrsteSportova.push(this.listaSportova[i].sport);
        if(this.listaSportova[i].vrsta=='ekipno') this.ekipniSport.push(this.listaSportova[i]);
      }
      this.userService.getMyDelegation(this.user.nacionalnost).subscribe((s: Sportista[]) => {
        this.mojaDelegacija = s.sort((a, b)=>{
          if(a.ime>b.ime) return 1;
          else if(a.ime<b.ime) return -1;
          else return 0;
        });
        this.userService.getMyTeams(this.user.nacionalnost).subscribe((e:Ekipa[])=>{
          this.mojeEkipe=e.sort((a, b)=>{
            if(a.sport>b.sport) return 1;
            else if(a.sport<b.sport) return -1;
            else return 0;
          })
        })
      })
    })
  }

  user: Korisnik;
  mojaDelegacija: Sportista[];
  mojeEkipe: Ekipa[];
  listaSportova: Sport[];
  vrsteSportova: string[] = [];
  vrsteDisciplina: string[] = [];
  ime: string = '';
  prezime: string = '';
  pol: string = '';
  zemlja: string;
  sport: string = '';
  disciplina: string = '';
  ima_disciplinu: boolean = true;
  ekipniSport:Sport[] = [];
  ekipni_sport:string='';
  dostupni: Sportista[]=[];
  ekipa: string[] = [];

  obrisi() {
    window.location.reload();
  }

  registruj() {
    if (this.ime == '' || this.prezime == '' || this.pol == '' || this.sport == '' || (this.disciplina == '' && this.ima_disciplinu)) {
      alert('Unesite sve podatke');
      return;
    }

    this.userService.proveriSportistu(this.ime, this.prezime, this.pol, this.zemlja).subscribe((s: Sportista) => {
      if (s) {
        if (s.sport != this.sport) { alert("Sportista ne sme se takmiciti u vise razlicitih sportova!"); return; }
        else{
          this.userService.proveriSportistuD(this.ime, this.prezime, this.pol, this.zemlja).subscribe((s:Sportista[])=>{
            for(let i = 0; i<s.length; i++){
              if(s[i].disciplina == this.disciplina) {alert("Takmicar je vec prijavljen za ovu disciplinu!"); return;}
            }
            this.userService.prijaviSportistu(this.ime, this.prezime, this.pol, this.zemlja, this.sport, this.disciplina).subscribe(msg=>{
              if(msg['message']=='ok'){
                alert('Takmicar uspesno prijavljen');
                window.location.reload();
              }
              else if(msg['message']=='formirano'){
                alert("Takmicenje je vec formirano")
              }
            })
          })
        }
      }
      else {
        this.userService.prijaviSportistu(this.ime, this.prezime, this.pol, this.zemlja, this.sport, this.disciplina).subscribe(msg=>{
          if(msg['message']=='ok'){
            
            window.location.reload();
          }
          else if(msg['message']=='formirano'){
            alert("Takmicenje je vec formirano")
          }
        })
      }
    })
  }

  pretraziDiscipline() {
    this.vrsteDisciplina = [];
    for (let i = 0; i < this.listaSportova.length; i++) {
      if (this.listaSportova[i].sport == this.sport && this.listaSportova[i].disciplina)
        this.vrsteDisciplina.push(this.listaSportova[i].disciplina);
    }
    this.disciplina = '';
    if (this.vrsteDisciplina.length > 0) this.ima_disciplinu = true;
    else this.ima_disciplinu = false;

  }

  dostupniSportisti(){
    this.dostupni=[];
    this.ekipa=[];
    let sdp = this.ekipni_sport.split(',', 3);
    for(let i = 0; i<this.mojaDelegacija.length; i++){
      if(this.mojaDelegacija[i].sport==sdp[0] && this.mojaDelegacija[i].disciplina==sdp[1] && this.mojaDelegacija[i].tim==false && this.mojaDelegacija[i].pol==sdp[2]){
        this.dostupni.push(this.mojaDelegacija[i]);
      }
    }
  }

  formirajEkipu() {
    if(this.ekipni_sport=="") {alert("Unesite sve podatke!"); return;}
    if(this.ekipa.length==0) {alert("Niste izabrali igrace za tim!"); return;}
    let sid = this.ekipni_sport.split(',', 2);
    let tim: Sportista[] = [];
    for(let i = 0; i<this.dostupni.length; i++){
      for(let j = 0; j<this.ekipa.length; j++){
        if(this.dostupni[i].ime+' '+this.dostupni[i].prezime==this.ekipa[j]){
          tim.push(this.dostupni[i]);
          this.dostupni[i].tim=true;
        }
      }
    }
    for(let i = 0; i<this.ekipniSport.length; i++){
      if(this.ekipniSport[i].sport==sid[0]){
        let min_max = this.ekipniSport[i].brojIgraca.split('/', 2);
        if(min_max.length==2){
          if(tim.length<parseInt(min_max[0])) {alert("Minimalan broj igraca u timu je "+min_max[0]); return;}
          if(tim.length>parseInt(min_max[1])) {alert("Maksimalan broj igraca u timu je "+min_max[1]); return;}
          break;
        }
        else{
          if(tim.length!=parseInt(min_max[0])) {alert("Tacan broj igraca u timu je "+min_max[0]); return;}
          break;
        }
      }
    }
    const data={
      sport:sid[0],
      disciplina:sid[1],
      drzava:this.zemlja,
      pol:tim[0].pol,
      tim:tim
    }
    this.userService.prijaviEkipu(data).subscribe(poruka=>{
      if(poruka['message']=='ok'){
        window.location.reload();
      }
      else if(poruka['message']=='formirano'){
        alert("Takmicenje je vec formirano");
      }
      else if(poruka['message']=='postoji'){
        alert("Postoji vec formiran tim.\nSamo jedan tim delegacije po sportu!")
      }
    });
  }

}

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class VodjaService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:4000'


  prijaviSportistu(ime, prezime, pol, zemlja, sport, disciplina){
    const data={
      ime:ime,
      prezime:prezime,
      pol:pol,
      drzava:zemlja,
      sport:sport,
      disciplina:disciplina,
      tim:false,
      osvojio:''
    }
    return this.http.post(`${this.url}/vodja/prijaviSportistu`, data);
  }

  prijaviEkipu(data){
    return this.http.post(`${this.url}/vodja/prijaviEkipu`, data);
  }

  proveriSportistu(ime, prezime, pol, zemlja){
    const data={
      ime:ime,
      prezime:prezime,
      pol:pol,
      drzava:zemlja
    }
    return this.http.post(`${this.url}/vodja/proveriSportistu`, data);
  }
  proveriSportistuD(ime, prezime, pol, zemlja){
    const data={
      ime:ime,
      prezime:prezime,
      pol:pol,
      drzava:zemlja
    }
    return this.http.post(`${this.url}/vodja/proveriSportistuD`, data);
  }

  getMyDelegation(drzava){
    const data={
      drzava:drzava
    }
    return this.http.post(`${this.url}/vodja/getMyDelegation`, data);
  }
  getMyTeams(drzava){
    const data={
      drzava:drzava
    }
    return this.http.post(`${this.url}/vodja/getMyTeams`, data);
  }
}

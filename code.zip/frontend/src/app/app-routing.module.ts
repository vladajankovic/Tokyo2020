import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DelegatComponent } from './delegat/delegat.component';
import { KorisnikComponent } from './korisnik/korisnik.component';
import { LoginComponent } from './login/login.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { MedaljeComponent } from './medalje/medalje.component';
import { NaslovnaComponent } from './naslovna/naslovna.component';
import { OrganizatorComponent } from './organizator/organizator.component';
import { PendingComponent } from './pending/pending.component';
import { PregledsportistaComponent } from './pregledsportista/pregledsportista.component';
import { PrijavisportistuComponent } from './prijavisportistu/prijavisportistu.component';
import { PromenalozinkeComponent } from './promenalozinke/promenalozinke.component';
import { RegisterComponent } from './register/register.component';
import { RekordiComponent } from './rekordi/rekordi.component';
import { SportistiComponent } from './sportisti/sportisti.component';
import { SportprijavaComponent } from './sportprijava/sportprijava.component';
import { TakmicenjeprijavaComponent } from './takmicenjeprijava/takmicenjeprijava.component';
import { VodjaComponent } from './vodja/vodja.component';
import { ZahteviregistracijaComponent } from './zahteviregistracija/zahteviregistracija.component';
import { ZemljeComponent } from './zemlje/zemlje.component';

const routes: Routes = [
  {path: '', redirectTo:'/mainpage', pathMatch:'full'},
  {path:'mainpage',component:MainpageComponent, children:[
    {path: '', component:NaslovnaComponent},
    {path: 'naslovna', component:NaslovnaComponent},
    {path: 'zemlje',  component: ZemljeComponent},
    {path: 'medalje', component: MedaljeComponent},
    {path: 'sportisti', component: SportistiComponent}
  ]},
  {path:'login', component:LoginComponent},
  {path:'register', component:RegisterComponent},
  {path:'pending', component:PendingComponent},
  {path:'korisnik', component:KorisnikComponent, children:[
    {path: '', redirectTo: '/mainpage', pathMatch: 'full'},
    {path: 'vodja', component:VodjaComponent, children:[
      {path:'', component:PrijavisportistuComponent},
      {path:'prijavi', component:PrijavisportistuComponent},
      {path:'pregled', component:PregledsportistaComponent}
    ]},
    {path: 'delegat', component:DelegatComponent},
    {path: 'organizator', component:OrganizatorComponent, children:[
      {path:'', component:ZahteviregistracijaComponent},
      {path:'zahtevi', component:ZahteviregistracijaComponent},
      {path:'sport', component:SportprijavaComponent},
      {path:'takmicenje', component:TakmicenjeprijavaComponent},
      {path:'rekordi', component:RekordiComponent}
    ]}
  ]},
  {path: 'promenalozinke', component:PromenalozinkeComponent},
  {path:'**', redirectTo:'/mainpage', pathMatch:'full'}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.css']
})
export class PendingComponent implements OnInit {

  constructor(private ruter:Router) { }

  ngOnInit(): void {
    setTimeout(()=>{
      this.ruter.navigate(['mainpage'])
    }, 7000)
  }

}

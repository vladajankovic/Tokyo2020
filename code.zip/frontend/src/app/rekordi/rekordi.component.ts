import { Component, OnInit } from '@angular/core';
import { Rekord } from '../models/rekord';
import { OrganizatorService } from '../organizator.service';

@Component({
  selector: 'app-rekordi',
  templateUrl: './rekordi.component.html',
  styleUrls: ['./rekordi.component.css']
})
export class RekordiComponent implements OnInit {

  constructor(private userService: OrganizatorService) { }

  ngOnInit(): void {
    this.userService.getRecords().subscribe((r:Rekord[])=>{
      this.rekordi=r;
    })
  }

  rekordi: Rekord[];

}

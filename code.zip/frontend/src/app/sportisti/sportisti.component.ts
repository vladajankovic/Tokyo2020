import { Component, OnInit } from '@angular/core';
import { Sport } from '../models/sport';
import { Sportista } from '../models/sportista';
import { Zemlja } from '../models/zemlja';
import { SiteService } from '../site.service';

@Component({
  selector: 'app-sportisti',
  templateUrl: './sportisti.component.html',
  styleUrls: ['./sportisti.component.css']
})
export class SportistiComponent implements OnInit {

  constructor(private site: SiteService) { }

  ngOnInit(): void {
    this.page=1;
    this.paginacija=localStorage.getItem('paginacija');
    this.site.getAllCountries().subscribe( (z:Zemlja[]) => {
      this.listaZemalja=z;
      this.site.getAllSports().subscribe( (s:Sport[]) => {
        this.listaSportova=s;
        for(let i = 0; i<this.listaSportova.length; i++){
          this.vrsteDisciplina.push(this.listaSportova[i].sport+' - '+this.listaSportova[i].disciplina);
          let flag = false;
          for(let j = 0; j<this.vrsteSportova.length; j++){
            if(this.listaSportova[i].sport==this.vrsteSportova[j]) flag = true;
          }
          if(!flag) this.vrsteSportova.push(this.listaSportova[i].sport);
        }
        this.site.getAllSportists().subscribe( (s:Sportista[]) => {
          this.listaSportista=s.sort((a, b)=>{
            if(a.ime>b.ime) return 1;
            else if(a.ime==b.ime) return 0;
            else return -1;
          });
          this.filterSportista=this.listaSportista;
          for(let i = 0; i<parseInt(this.paginacija); i++){
            if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
            else this.prikazaniSportisti.push(this.dummy);
          }
          if(this.filterSportista.length>10) this.last=false;
          else this.last=true;
          if(localStorage.getItem('filter')){
            let filter=localStorage.getItem('filter').split(',', 6);
            this.ime = filter[0];
            this.zemlja=filter[1];
            this.sport=filter[2];
            this.disciplina=filter[3];
            this.pol=filter[4];
            if(filter[5]=='true') this.osvojio=true;
            else this.osvojio=false;
            {
              let filter2 = [];
              localStorage.setItem('filter', this.ime+','+this.zemlja+','+this.sport+','+this.disciplina+','+this.pol+','+this.osvojio);
              //AKO JE OSVOJI MEDALJE
              if(this.osvojio==true){
                this.filterSportista=[];
                for(let i = 0; i<this.listaSportista.length; i++){
                  if(this.listaSportista[i].osvojio != ''){
                    this.filterSportista.push(this.listaSportista[i]);
                  }
                }
              }

              //AKO JE IZABRAN POL
              if(this.pol != ''){
                for(let i = 0; i<this.filterSportista.length; i++){
                  if(this.filterSportista[i].pol == this.pol){
                    filter2.push(this.filterSportista[i]);
                  }
                }
                this.filterSportista=filter2;
              }

              //AKO JE IZABRAN SPORT
              if(this.sport != ''){
                filter2=[];
                for(let i = 0; i<this.filterSportista.length; i++){
                  if(this.filterSportista[i].sport == this.sport){
                    filter2.push(this.filterSportista[i]);
                  }
                }
                this.filterSportista=filter2;
              }

              //AKO JE IZABRANA DISCIPLINA
              if(this.disciplina != ''){
                let sid=this.disciplina.split(' - ', 2);
                filter2=[];
                for(let i = 0; i<this.filterSportista.length; i++){
                  if(this.filterSportista[i].sport == sid[0]){
                    if(this.filterSportista[i].disciplina==sid[1])
                        filter2.push(this.filterSportista[i]);
                  }
                }
                this.filterSportista=filter2;
              }

              //AKO JE IZABRANA ZEMLJA
              if(this.zemlja != ''){
                filter2=[];
                for(let i = 0; i<this.filterSportista.length; i++){
                  if(this.filterSportista[i].drzava==this.zemlja){
                    filter2.push(this.filterSportista[i]);
                  }
                }
                this.filterSportista=filter2;
              }

              //AKO SE PRETRAZUJE PO NAZIVU
              if(this.ime != ''){
                filter2=[];
                this.filterSportista.forEach(s=>{
                  let ip = s.ime+' '+s.prezime;
                  if(ip.match(this.ime)) filter2.push(s)
                })
                this.filterSportista=filter2;
              }

              this.prikazaniSportisti=[]
              for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
                if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
                else this.prikazaniSportisti.push(this.dummy);
              }
            }
          }
          if(parseInt(this.paginacija)*(this.page)>this.filterSportista.length) this.last=true;
        })
      })

    })
    
    
  }

  ime:string='';
  zemlja:string='';
  sport:string = '';
  disciplina:string = '';
  pol:string = '';
  osvojio:boolean=false;
  listaZemalja: Zemlja[];
  listaSportova: Sport[];
  vrsteSportova: string[] = [];
  vrsteDisciplina: string[] = [];
  listaSportista: Sportista[];
  filterSportista: Sportista[];
  prikazaniSportisti: Sportista[] = [];
  page: number;
  paginacija:string;
  first:boolean=true;
  last:boolean;
  ima_disciplinu:boolean = true;
  dummy: Sportista = {ime:'', prezime:'', pol:'', drzava:'', sport:'', disciplina:'', tim:false, osvojio:''}

  sledSportisti(){
    if(this.last) return;
    this.first=false;
    this.page++;
    this.prikazaniSportisti=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
      else this.prikazaniSportisti.push(this.dummy);
    }
    if(parseInt(this.paginacija)*(this.page)>this.filterSportista.length) this.last=true;
  }

  prethSportisti(){
    if(this.first) return;
    this.last=false;
    this.page--;
    this.prikazaniSportisti=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
      else this.prikazaniSportisti.push(this.dummy);
    }
    if(this.page==1) this.first=true;
  }

  reset(){
    this.page=1;
    localStorage.setItem('paginacija', this.paginacija);
    window.location.reload();
  }

  pretrazi(){
    this.filterSportista=this.listaSportista;
    let filter2 = [];
    localStorage.setItem('filter', this.ime+','+this.zemlja+','+this.sport+','+this.disciplina+','+this.pol+','+this.osvojio);
    /*//AKO JE OSVOJI MEDALJE
    if(this.osvojio==true){
      this.filterSportista=[];
      for(let i = 0; i<this.listaSportista.length; i++){
        if(this.listaSportista[i].osvojio != ''){
          this.filterSportista.push(this.listaSportista[i]);
        }
      }
    }

    //AKO JE IZABRAN POL
    if(this.pol != ''){
      for(let i = 0; i<this.filterSportista.length; i++){
        if(this.filterSportista[i].pol == this.pol){
          filter2.push(this.filterSportista[i]);
        }
      }
      this.filterSportista=filter2;
    }

    //AKO JE IZABRAN SPORT
    if(this.sport != ''){
      filter2=[];
      for(let i = 0; i<this.filterSportista.length; i++){
        if(this.filterSportista[i].sport == this.sport){
          filter2.push(this.filterSportista[i]);
        }
      }
      this.filterSportista=filter2;
    }

    //AKO JE IZABRANA DISCIPLINA
    if(this.disciplina != ''){
      let sid=this.disciplina.split(' - ', 2);
      filter2=[];
      for(let i = 0; i<this.filterSportista.length; i++){
        if(this.filterSportista[i].sport == sid[0]){
          if(this.filterSportista[i].disciplina==sid[1])
              filter2.push(this.filterSportista[i]);
        }
      }
      this.filterSportista=filter2;
    }

    //AKO JE IZABRANA ZEMLJA
    if(this.zemlja != ''){
      filter2=[];
      for(let i = 0; i<this.filterSportista.length; i++){
        if(this.filterSportista[i].drzava==this.zemlja){
          filter2.push(this.filterSportista[i]);
        }
      }
      this.filterSportista=filter2;
    }

    //AKO SE PRETRAZUJE PO NAZIVU
    if(this.ime != ''){
      filter2=[];
      this.filterSportista.forEach(s=>{
        let ip = s.ime+' '+s.prezime;
        if(ip.match(this.ime)) filter2.push(s)
      })
      this.filterSportista=filter2;
    }

    this.prikazaniSportisti=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
      else this.prikazaniSportisti.push(this.dummy);
    }*/
    window.location.reload();

  }

  obrisi(){
    localStorage.removeItem('filter')
    window.location.reload();
  }

  pretraziDiscipline(){
    this.vrsteDisciplina = [];
    for(let i = 0; i<this.listaSportova.length; i++){
      if(this.sport=='' || this.listaSportova[i].sport==this.sport && this.listaSportova[i].disciplina) 
        this.vrsteDisciplina.push(this.listaSportova[i].sport+' - '+this.listaSportova[i].disciplina);
    }
    this.disciplina='';
    if(this.vrsteDisciplina.length>0) this.ima_disciplinu=true;
    else this.ima_disciplinu=false;
    
  }

  sortIme(){
    this.filterSportista.sort((a, b)=>{
      if(a.ime>b.ime) return 1;
      else if(a.ime==b.ime) return 0;
      else return -1;
    });
    this.prikazaniSportisti=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
      else this.prikazaniSportisti.push(this.dummy);
    }
  }

  sortPrezime(){
    this.filterSportista.sort((a, b)=>{
      if(a.prezime>b.prezime) return 1;
      else if(a.prezime==b.prezime) return 0;
      else return -1;
    });
    this.prikazaniSportisti=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
      else this.prikazaniSportisti.push(this.dummy);
    }
  }

  sortPol(){
    this.filterSportista.sort((a, b)=>{
      if(a.pol>b.pol) return 1;
      else if(a.pol==b.pol) return 0;
      else return -1;
    });
    this.prikazaniSportisti=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
      else this.prikazaniSportisti.push(this.dummy);
    }
  }

  sortDrzava(){
    this.filterSportista.sort((a, b)=>{
      if(a.drzava>b.drzava) return 1;
      else if(a.drzava==b.drzava) return 0;
      else return -1;
    });
    this.prikazaniSportisti=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
      else this.prikazaniSportisti.push(this.dummy);
    }
  }

  sortSport(){
    this.filterSportista.sort((a, b)=>{
      if(a.sport>b.sport) return 1;
      else if(a.sport==b.sport) return 0;
      else return -1;
    });
    this.prikazaniSportisti=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
      else this.prikazaniSportisti.push(this.dummy);
    }
  }

  sortDisciplina(){
    this.filterSportista.sort((a, b)=>{
      if(a.disciplina>b.disciplina) return 1;
      else if(a.disciplina==b.disciplina) return 0;
      else return -1;
    });
    this.prikazaniSportisti=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.filterSportista[i]) this.prikazaniSportisti.push(this.filterSportista[i]);
      else this.prikazaniSportisti.push(this.dummy);
    }
  }

}

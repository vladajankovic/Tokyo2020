import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Korisnik } from '../models/korisnik';
import { Zemlja } from '../models/zemlja';
import { SiteService } from '../site.service';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private site: SiteService, private userService: UserService, private ruter: Router) { }

  ngOnInit(): void {
    this.site.getAllCountries().subscribe((z: Zemlja[]) => {
      this.listaZemalja = z;
    })
  }

  listaZemalja: Zemlja[];
  username: string = '';
  password1: string = '';
  password2: string = '';
  ime: string = '';
  prezime: string = '';
  zemlja: string = '';
  email: string = '';
  tip: string = '';

  badusername: string;
  badpass1: string;
  badpass2: string;
  badime: string;
  badprezime: string;
  badzemlja: string;
  bademail: string;
  badtip: string;
  errmessage: string[] = [];
  erruser: string = '';
  errpass: string = '';
  errvalid:string = '';
  errdlgt: string = '';
  exit1: boolean = false;
  exit2: boolean = false;
  exit3: boolean = false;
  exit4: boolean = false;
  exit5: boolean = false;
  lenflag: boolean = true;
  fourinarowflag: boolean = true;
  firstletterflag: boolean = true;
  nbrojevaflag: boolean = true;
  nspecflag: boolean = true;
  nmalihflag: boolean = true;
  nvelikflag: boolean = true;

  emailregex = /^[\w!#$%&'*+\-\/\.=?^_`{|]{1,64}@[a-z]+\.com/

  validateData() {
    this.bademail = this.badime = this.badpass1 = this.badpass2 = this.badprezime = this.badtip = this.badusername = this.badzemlja = '';
    this.errmessage = [];
    let ok: boolean;
    if (this.username == '') this.badusername = "Unesite korisnicko ime!";
    if (this.password1 == '') this.badpass1 = "Unesite lozinku!";
    if (this.password2 == '') this.badpass2 = "Unesite potvrdu lozinke!";
    if (this.ime == '') this.badime = "Unesite ime!";
    if (this.prezime == '') this.badprezime = "Unesite prezime!";
    if (this.zemlja == '') this.badzemlja = "Odaberite vasu drzavu!";
    if (this.email == '') this.bademail = "Unesite vasu email adresu!";
    if (this.tip == '') this.badtip = "Izaberite tipa korisnika!";
    if (this.username == '' || this.password1 == '' || this.password2 == '' || this.ime == '' || this.prezime == '' || this.zemlja == '' || this.email == '' || this.tip == '') {
      ok = false;
    }
    else ok = true;
    return ok;
  }

  obrisi() {
    window.location.reload();
  }

  usercheck() {
    this.userService.checkUsername(this.username).subscribe((u: Korisnik) => {
      if (u) {
        this.erruser = 'Vec postoji korisnik sa datim korisnickim imenom!';
        this.exit1 = true;
      }
      else {
        this.erruser = '';
        this.exit1 = false;
      }
    })
  }

  passcheck() {
    if (this.password1 != this.password2) {
      this.errpass = 'Lozinka za potvrdu se mora poklapati sa vasom odabranom lozinkom!\n';
      this.exit2 = true;
    }
    else {
      this.errpass = '';
      this.exit2 = false;
    }
  }
  passpatern() {
    this.exit5 = false;
    let dcnt = 0; let scnt = 0; let mcnt = 0; let vcnt = 0;
    this.lenflag = this.fourinarowflag = this.firstletterflag = false;
    this.nbrojevaflag = this.nspecflag = this.nmalihflag = this.nvelikflag = false;
    if (this.password1.length > 12 || this.password1.length < 8) this.lenflag = this.exit5 = true;

    let reg = /(.)\1\1\1/
    if (reg.test(this.password1)) this.fourinarowflag = this.exit5 = true;

    reg = /^[a-zA-Z].*/
    if (!reg.test(this.password1)) this.firstletterflag = this.exit5 = true;

    let dreg = /\d/; let sreg = /\W|_/; let mreg = /[a-z]/; let vreg = /[A-Z]/;
    for (let i = 0; i < this.password1.length; i++) {
      if (dreg.test(this.password1[i])) dcnt++;
      if (sreg.test(this.password1[i])) scnt++;
      if (mreg.test(this.password1[i])) mcnt++;
      if (vreg.test(this.password1[i])) vcnt++;
    }
    if (dcnt < 2) this.nbrojevaflag = this.exit5 = true;
    if (scnt < 2) this.nspecflag = this.exit5 = true;
    if (mcnt < 3) this.nmalihflag = this.exit5 = true;
    if (vcnt < 1) this.nvelikflag = this.exit5 = true;

    if (this.password1 == '') {
      this.lenflag =this.fourinarowflag = this.firstletterflag = this.nbrojevaflag = true;
      this.nspecflag = this.nmalihflag = this.nvelikflag = true;
    }
  }

  vodjacheck() {
    if (this.tip == 'delegat_vodja') {
      this.userService.getDelegatVodju(this.zemlja).subscribe((u: Korisnik) => {
        if (u) {
          this.errdlgt = "Vodja nacionalne delegacije za ovu drzavu vec postoji! Najvise moze jedan vodja nacionalne delegacije po drzavi.";
          this.exit3 = true;
        }
        else {
          this.errdlgt = "";
          this.exit3 = false;
        }
      })
    }
    else {
      this.errdlgt = "";
      this.exit3 = false;
    }
  }

  register() {
    if (!this.validateData()) this.exit4 = true;
    if (!this.emailregex.test(this.email)) {
      this.errmessage.push('Ne mozete koristiti ovu email adresu!');
      this.errmessage.push('Primer dobre email adrese: test.123@gmail.com, my.404.email@yahoo.com');
      this.errmessage.push('Koristite top-level domen {.com} i neki od preporucenih email domena kao sto su gmail, yahoo, outlook, hotmail, ...\n');
      this.exit4 = true;
    }
    if(this.exit5) this.errvalid='Lozinka nije u ispravnom formatu! Pokusajte ponovo.'
    else this.errvalid='';
    if (this.exit1 || this.exit2 || this.exit3 || this.exit4 || this.exit5) return;
    const data = {
      korisnicko_ime: this.username,
      lozinka: this.password1,
      ime: this.ime,
      prezime: this.prezime,
      nacionalnost: this.zemlja,
      email: this.email,
      tip_korisnika: this.tip,
      odobren: 0
    }
    this.userService.registerUser(data).subscribe(poruka => {
      if (poruka['message'] == 'ok') {
        this.ruter.navigate(['mainpage']);
      }
      else {
        alert('Neuspesna registracija!')
      }
    })

  }

}

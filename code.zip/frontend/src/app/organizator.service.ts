import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OrganizatorService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:4000'

  getAllPendingUsers(){
    return this.http.get(`${this.url}/organizator/getPendingUsers`);
  }

  getRecords(){
    return this.http.get(`${this.url}/organizator/getRecords`);
  }

  getAllTeams(){
    return this.http.get(`${this.url}/organizator/getAllTeams`);
  }

  getAllDelegats(){
    return this.http.get(`${this.url}/organizator/getAllDelegats`);
  }

  getAllTakmicenja(){
    return this.http.get(`${this.url}/organizator/getAllTakmicenja`);
  }

  odbij(korisnicko_ime){
    const data={
      korisnicko_ime:korisnicko_ime
    }
    return this.http.post(`${this.url}/organizator/remove`, data);
  }

  odobri(korisnicko_ime, nacionalnost, tip, ime, prezime){
    const data={
      korisnicko_ime:korisnicko_ime,
      nacionalnost:nacionalnost,
      tip:tip,
      ime:ime,
      prezime:prezime
    }
    return this.http.post(`${this.url}/organizator/allowRequest`, data);
  }

  registrujSport(sport, disciplina, vrsta, brojIgraca){
    const data={
      sport:sport,
      disciplina:disciplina,
      vrsta:vrsta,
      brojIgraca:brojIgraca
    }
    return this.http.post(`${this.url}/organizator/registrujSport`, data);
  }

  registrujTakmicenje(data){
    return this.http.post(`${this.url}/organizator/registrujTakmicenje`, data);
  }

  proveri(sport, disciplina, pol){
    const data={
      sport:sport,
      disciplina:disciplina,
      pol:pol
    }
    return this.http.post(`${this.url}/organizator/proveri`, data);
  }
}

import { Component, OnInit } from '@angular/core';
import { Medalje } from 'src/app/models/medalje';
import { SiteService } from '../site.service';

@Component({
  selector: 'app-medalje',
  templateUrl: './medalje.component.html',
  styleUrls: ['./medalje.component.css']
})
export class MedaljeComponent implements OnInit {

  constructor(private site: SiteService) { }

  ngOnInit(): void {
    this.site.getAllMedals().subscribe( (m:Medalje[]) =>{
      this.medaljeSvihDrzava=m;
      this.ukupno();
      for(let i = 0; i<this.medaljeSvihDrzava.length; i++){
        this.medaljeSvihDrzava[i].rang=i+1;
      }
      this.prikazaneMedalje=[]
      this.paginacija=localStorage.getItem('paginacija')
      this.page=1;
      for(let i = 0; i<parseInt(this.paginacija); i++){
        this.prikazaneMedalje.push(this.medaljeSvihDrzava[i]);
      }
    } )
    
  }

  medaljeSvihDrzava: Medalje[];
  prikazaneMedalje: Medalje[]=[];
  page: number;
  paginacija:string;
  first=true;
  last=false;
  dummy: Medalje = {naziv:'', z:undefined, s:undefined, b:undefined, u:undefined, rang:undefined}

  sledZemlje(){
    if(this.last) return;
    this.first=false;
    this.page++;
    this.prikazaneMedalje=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.medaljeSvihDrzava[i]) this.prikazaneMedalje.push(this.medaljeSvihDrzava[i]);
      else this.prikazaneMedalje.push(this.dummy);
    }
    
    if(parseInt(this.paginacija)*(this.page)>this.medaljeSvihDrzava.length) this.last=true;
  }

  prethZemlje(){
    if(this.first) return;
    this.last=false;
    this.page--;
    this.prikazaneMedalje=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      this.prikazaneMedalje.push(this.medaljeSvihDrzava[i]);
    }
    if(this.page==1) this.first=true;
  }

  reset(){
    this.page=1;
    localStorage.setItem('paginacija', this.paginacija);
    window.location.reload();
  }

  ukupno(){
    this.medaljeSvihDrzava.sort((a, b)=>{
      if(a.u>b.u) return -1;
      else if(a.u<b.u) return 1;
      else return 0;
    });
    for(let i = 0; i<this.medaljeSvihDrzava.length; i++){
      this.medaljeSvihDrzava[i].rang=i+1;
    }
    this.prikazaneMedalje=[]
    this.page=1;
    for(let i = 0; i<parseInt(this.paginacija); i++){
      this.prikazaneMedalje.push(this.medaljeSvihDrzava[i]);
    }
  }

  zlato(){
    this.medaljeSvihDrzava.sort((a,b)=>{
      if(a.z>b.z) return -1;
      else if(a.z<b.z) return 1;
      else{
        if(a.s>b.s) return -1;
        else if(a.s<b.s) return 1;
        else{
          if(a.b>b.b) return -1;
          else if(a.b<b.b) return 1;
          else return 0;
        }
      }
    })
    for(let i = 0; i<this.medaljeSvihDrzava.length; i++){
      this.medaljeSvihDrzava[i].rang=i+1;
    }
    this.prikazaneMedalje=[]
    this.page=1;
    for(let i = 0; i<parseInt(this.paginacija); i++){
      this.prikazaneMedalje.push(this.medaljeSvihDrzava[i]);
    }
  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Korisnik } from '../models/korisnik';

@Component({
  selector: 'app-korisnik',
  templateUrl: './korisnik.component.html',
  styleUrls: ['./korisnik.component.css']
})
export class KorisnikComponent implements OnInit {

  constructor(private ruter:Router) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem('ulogovan'))
  }

  user: Korisnik;

  odjava(){
    localStorage.removeItem('ulogovan')
    this.ruter.navigate(['mainpage'])
  }

  passchange(){
    localStorage.setItem('back', this.ruter.url)
    this.ruter.navigate(['promenalozinke'])
  }

  naslovna(){
    this.ruter.navigate(['mainpage'])
  }

}

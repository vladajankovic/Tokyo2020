import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Korisnik } from '../models/korisnik';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private userService:UserService, private ruter:Router) { }

  ngOnInit(): void {
  }

  username:string='';
  password:string='';

  prijava(){
    this.userService.login(this.username, this.password).subscribe((u:Korisnik)=>{
      if(u){
        if(u.odobren==0) this.ruter.navigate(['pending'])
        else{
          localStorage.setItem('ulogovan', JSON.stringify(u));
          this.ruter.navigate(['mainpage']);
        }
      }
      else{
        alert("Korisnik nije pronadjen.\nProverite ispravnost podataka.")
      }
    })
  }

}

export class Sportista{
    ime:string;
    prezime:string;
    pol:string;
    drzava:string;
    sport:string;
    disciplina:string;
    tim:boolean;
    osvojio:string;
    
}
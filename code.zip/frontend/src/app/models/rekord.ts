export class Rekord{
    disciplina:string;
    rekord:string;
    sportista:string;
    nacionalnost:string;
    mesto:string;
    godina:string;
}
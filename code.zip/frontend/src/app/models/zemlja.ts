export class Zemlja{
    naziv:string;
    brojSportista:number;
}
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class SiteService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:4000'

  getAllCountries(){
    return this.http.get(`${this.url}/site/allCountries`)
  }
  getAllMedals(){
    return this.http.get(`${this.url}/site/allMedals`)
  }
  getAllSports(){
    return this.http.get(`${this.url}/site/allSports`)
  }
  getAllSportists(){
    return this.http.get(`${this.url}/site/allSportists`)
  }
}

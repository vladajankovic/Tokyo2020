import express from 'express'
import Sportista from '../models/sportista';
import Delegat from '../models/delegat';
import Takmicenje from '../models/takmicenje';
import Medalje from '../models/medalje';

export class delegatController{

    dohvatiSebe = (req: express.Request, res: express.Response) => {
        let korisnicko_ime = req.body.korisnicko_ime;

        Delegat.findOne({'korisnicko_ime':korisnicko_ime}, (err, d)=>{
            if(err) console.log(err);
            else res.json(d);
        })

    }

    dohvatiTakmicenje = (req: express.Request, res: express.Response) => {
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let pol = req.body.pol;

        Takmicenje.findOne({'sport':sport, 'disciplina':disciplina, 'pol':pol}, (err, t)=>{
            if(err) console.log(err);
            else res.json(t);
        })

    }

    upisiSatnicu = (req: express.Request, res: express.Response) => {
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let pol = req.body.pol;
        let datum = req.body.datum;
        let vreme = req.body.vreme;
        let mesto = req.body.mesto;

        Takmicenje.findOne({'datumPocetka':datum, 'vremePocetka':vreme, 'lokacija':mesto}, (err, t)=>{
            if(err) console.log(err);
            else{
                if(t) res.json({'msg':'zauzeto'})
                else{
                    Takmicenje.collection.updateOne({'sport':sport, 'disciplina':disciplina, 'pol':pol},{$set:{'datumPocetka':datum, 'vremePocetka':vreme, 'lokacija':mesto}}).then(k=>{
                        res.status(200).json({'msg':'ok'})
                    }).catch(err=>{
                        res.status(400).json(err);
                    })
                }
            }
        })

    }

    upisiRezultat = (req: express.Request, res: express.Response) => {
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let pol = req.body.pol;
        let r = req.body.rez

        Takmicenje.collection.updateOne({'sport':sport, 'disciplina':disciplina, 'pol':pol},{$push:{'finale':r}}).then(k=>{
            res.status(200).json({'msg':'ok'})
        }).catch(err=>{
            res.status(400).json(err);
        })

    }

    setRezultat = (req: express.Request, res: express.Response) => {
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let pol = req.body.pol;
        let rezultat = req.body.rezultat;

        Takmicenje.collection.updateOne({'sport':sport, 'disciplina':disciplina, 'pol':pol},{$set:{'finale':rezultat, 'zavrseno':true}}).then(k=>{
            res.status(200).json({'msg':'ok'})
        }).catch(err=>{
            res.status(400).json(err);
        })

    }

    napraviFinale = (req: express.Request, res: express.Response) => {
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let pol = req.body.pol;
        let polu = req.body.polu;

        Takmicenje.collection.updateOne({'sport':sport, 'disciplina':disciplina, 'pol':pol},{$set:{'finale':polu}}).then(k=>{
            res.status(200).json({'msg':'ok'})
        }).catch(err=>{
            res.status(400).json(err);
        })

    }

    napraviPolufinale = (req: express.Request, res: express.Response) => {
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let pol = req.body.pol;
        let polu = req.body.polu;

        Takmicenje.collection.updateOne({'sport':sport, 'disciplina':disciplina, 'pol':pol},{$set:{'polufinale':polu}}).then(k=>{
            res.status(200).json({'msg':'ok'})
        }).catch(err=>{
            res.status(400).json(err);
        })

    }

    napraviCetvrtfinale = (req: express.Request, res: express.Response) => {
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let pol = req.body.pol;
        let polu = req.body.polu;

        Takmicenje.collection.updateOne({'sport':sport, 'disciplina':disciplina, 'pol':pol},{$set:{'cetvrtfinale':polu}}).then(k=>{
            res.status(200).json({'msg':'ok'})
        }).catch(err=>{
            res.status(400).json(err);
        })

    }

    napraviOsminafinala = (req: express.Request, res: express.Response) => {
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let pol = req.body.pol;
        let polu = req.body.polu;

        Takmicenje.collection.updateOne({'sport':sport, 'disciplina':disciplina, 'pol':pol},{$set:{'osminafinala':polu}}).then(k=>{
            res.status(200).json({'msg':'ok'})
        }).catch(err=>{
            res.status(400).json(err);
        })

    }

    dodeliMedalju = (req: express.Request, res: express.Response) => {
        let ime = req.body.ime;
        let prezime = req.body.prezime;
        let pol = req.body.pol;
        let drzava = req.body.drzava;
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let mesto = req.body.mesto;
        console.log(req.body)

        Sportista.collection.updateOne({'ime':ime, 'prezime':prezime, 'pol':pol, 'drzava':drzava, 'sport':sport, 'disciplina':disciplina}, {$set:{'osvojio':mesto}}).then(s=>{
            if(mesto=='zlato') Medalje.collection.updateOne({'naziv':drzava}, {$inc:{'z':1, 'u':1}})
            if(mesto=='srebro') Medalje.collection.updateOne({'naziv':drzava}, {$inc:{'s':1, 'u':1}})
            if(mesto=='bronza') Medalje.collection.updateOne({'naziv':drzava}, {$inc:{'b':1, 'u':1}})
        })

    }

    

}
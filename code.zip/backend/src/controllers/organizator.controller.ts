import express, { json } from 'express'
import Rekord from '../models/rekord'
import Korisnik from '../models/korisnik'
import Sport from '../models/sport'
import Ekipa from '../models/ekipa'
import Delegat from '../models/delegat'
import Takmicenje from '../models/takmicenje'

export class organizatorController{

    getPendingUsers = (req: express.Request, res: express.Response) => {
        Korisnik.find({'odobren':0}, (err, u) => {
            if(err) console.log(err);
            else res.json(u);
        })
    }

    getRecords = (req: express.Request, res: express.Response) => {
        Rekord.find({}, (err, r)=>{
            if(err) console.log(err);
            else res.json(r);
        })
    }

    getAllTeams = (req: express.Request, res: express.Response) => {
        Ekipa.find({}, (err, r)=>{
            if(err) console.log(err);
            else res.json(r);
        })
    }

    getAllDelegats = (req: express.Request, res: express.Response) => {
        Delegat.find({}, (err, r)=>{
            if(err) console.log(err);
            else res.json(r);
        })
    }

    getAllTakmicenja = (req: express.Request, res: express.Response) => {
        Takmicenje.find({}, (err, r)=>{
            if(err) console.log(err);
            else res.json(r);
        })
    }

    remove = (req: express.Request, res: express.Response) => {
        let korisnicko_ime = req.body.korisnicko_ime;

        Korisnik.deleteOne({'korisnicko_ime':korisnicko_ime}, (err)=>{
            if(err) console.log(err);
            else{
                res.json({'message': 'removed'})
            }
        })
    }

    allowRequest = (req: express.Request, res: express.Response) => {
        let korisnicko_ime = req.body.korisnicko_ime;
        let nacionalnost = req.body.nacionalnost;
        let tip_korisnika = req.body.tip;
        let ime = req.body.ime;
        let prezime = req.body.prezime;

        Korisnik.collection.updateOne({'korisnicko_ime':korisnicko_ime}, {$set:{'odobren':1}}).then(k=>{
            console.log('Odobren')
            if(tip_korisnika=='delegat_vodja'){
                console.log('Trazenje ostalih vodja')
                Korisnik.find({'nacionalnost':nacionalnost, 'tip_korisnika':tip_korisnika, 'odobren':0}, (err, u)=>{
                    if(err) console.log(err);
                    else{
                        if(u.length>0){
                            console.log('Nadjeno je jos '+ u.length);
                            Korisnik.deleteMany({'nacionalnost':nacionalnost, 'tip_korisnika':tip_korisnika, 'odobren':0}, (err)=>{
                                if(err) console.log(err);
                                else console.log('uspesno')
                            })
                        }
                    }
                })
            }
            else{
                let delegat = new Delegat({'korisnicko_ime':korisnicko_ime, 'ime':ime, 'prezime':prezime, 'nadgledanja':[]})
                delegat.save().catch(err=>res.status(400).json(err))
            }
            
            res.status(200).json({'msg':"ok"})
        }).catch(err=>{
            res.status(400).json(err);
        })

        
    }

    registrujSport = (req: express.Request, res: express.Response) => {
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let vrsta = req.body.vrsta;
        let brojIgraca = req.body.brojIgraca;

        Sport.findOne({'sport':sport, 'disciplina':disciplina, 'vrsta':vrsta, 'brojIgraca':brojIgraca}, (err, s)=>{
            if(err) console.log(err);
            else{
                if(s) res.json({'msg':'postoji'});
                else{
                    let sp = new Sport(req.body);
                    sp.save().then(s=>{
                        res.status(200).json({'msg':'ok'})
                    }).catch(err=>{
                        res.status(400).json(err);
                    })
                }
            }
        })
    }

    registrujTakmicenje = (req: express.Request, res: express.Response) => {
        console.log(req.body);
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let pol = req.body.pol;
        let delegati = req.body.delegati;

        Takmicenje.findOne({'sport':sport, 'disciplina':disciplina, 'pol':pol}, (err, t)=>{
            if(err) console.log(err);
            else{
                if(t) res.json({'msg':'postoji'});
                else{
                    let takmicenje = new Takmicenje(req.body);
                    takmicenje.save().then(s=>{
                        for(let i = 0; i<delegati.length; i++){
                            Delegat.collection.updateOne({'korisnicko_ime':delegati[i].korisnicko_ime}, {$push:{'nadgledanja':{sport:sport, disciplina:disciplina, pol:pol}}})
                        }
                        res.status(200).json({'msg':'ok'})
                    }).catch(err=>{
                        res.status(400).json(err);
                    })
                }
            }
        })
        
    }

    proveri = (req: express.Request, res: express.Response) => {
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let pol = req.body.pol;
        Takmicenje.findOne({'sport':sport, 'disciplina':disciplina, 'pol':pol}, (err, t)=>{
            if(err) console.log(err)
            else{
                if(t) res.json({'msg':'postoji'});
                else res.json({'msg':'ok'});
            }
        })
    }

}
import express from 'express'
import Takmicenje from '../models/takmicenje';
import Sportista from '../models/sportista';
import Zemlja from '../models/zemlja';
import Ekipa from '../models/ekipa';

export class vodjaController {

    getMyDelegation = (req: express.Request, res: express.Response) => {
        let drzava = req.body.drzava;

        Sportista.find({'drzava':drzava}, (err, users)=>{
            if(err) console.log(err);
            else res.json(users)
        })
    }

    getMyTeams = (req: express.Request, res: express.Response) => {
        let drzava = req.body.drzava;

        Ekipa.find({'drzava':drzava}, (err, users)=>{
            if(err) console.log(err);
            else res.json(users)
        })
    }

    proveriSportistu = (req: express.Request, res: express.Response) => {
        let ime = req.body.ime;
        let prezime = req.body.prezime;
        let pol = req.body.pol;
        let drzava = req.body.drzava;

        Sportista.findOne({'ime':ime, 'prezime':prezime, 'pol':pol, 'drzava':drzava}, (err, user)=>{
            if(err) console.log(err);
            else res.json(user)
        })
    }
    proveriSportistuD = (req: express.Request, res: express.Response) => {
        let ime = req.body.ime;
        let prezime = req.body.prezime;
        let pol = req.body.pol;
        let drzava = req.body.drzava;

        Sportista.find({'ime':ime, 'prezime':prezime, 'pol':pol, 'drzava':drzava}, (err, users)=>{
            if(err) console.log(err);
            else res.json(users)
        })
    }

    prijaviSportistu = (req: express.Request, res: express.Response) => {
        let ime = req.body.ime;
        let prezime = req.body.prezime;
        let pol = req.body.pol;
        let drzava = req.body.drzava;
        let sport = req.body.sport;
        let disciplina = req.body.disciplina;
        let sportista = new Sportista(req.body)
        console.log(sportista)

        Takmicenje.findOne({'sport':sport, 'disciplina':disciplina, 'pol':pol}, (err, t)=>{
            if(err) console.log(err);
            else{
                if(t){
                    res.json({ 'message': 'formirano' })
                }
                else{
                    sportista.save().then(korisnik => {
                        Sportista.find({'ime':ime, 'prezime':prezime, 'pol':pol, 'drzava':drzava}, (err, users)=>{
                            if(err) console.log(err);
                            else{
                                if(users.length==1){
                                    Zemlja.collection.updateOne({'naziv':drzava}, {$inc:{'brojSportista':1}})
                                }
                            }
                        })
                        res.status(200).json({ 'message': 'ok' })
                    }).catch(err => {
                        res.status(400).json(err)
                    })
                }
            }
        })
        
    }

    prijaviEkipu = (req: express.Request, res: express.Response) => {
        let data = req.body;
        const ekipa = new Ekipa(req.body)
        console.log(data);
        console.log(ekipa);

        Takmicenje.findOne({'sport':data.sport, 'disciplina':data.disciplina, 'pol':data.pol}, (err, t)=>{
            if(err) console.log(err);
            else{
                if(t){
                    res.json({ 'message': 'formirano' })
                }
                else{
                    Ekipa.findOne({'sport':data.sport, 'disciplina':data.disciplina, 'pol':data.pol, 'drzava':data.drzava}, (err, tim)=>{
                        if(err) console.log(err);
                        else{
                            if(tim){
                                res.json({ 'message': 'postoji' })
                            }
                            else{
                                ekipa.save().then(korisnik => {
                                    for(let i = 0; i<data.tim.length; i++){
                                        Sportista.collection.updateOne({'ime':data.tim[i].ime, 'prezime':data.tim[i].prezime, 'pol':data.tim[i].pol, 'drzava':data.tim[i].drzava}, {$set:{'tim':true}})
                                    }
                                    res.status(200).json({ 'message': 'ok' })
                                }).catch(err => {
                                    res.status(400).json(err)
                                })
                            }
                        }
                    })
                }
            }
        })
        
    }

}
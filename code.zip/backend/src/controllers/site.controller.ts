import express, { Response } from 'express'
import Zemlja from '../models/zemlja'
import Medalje from '../models/medalje'
import Sport from '../models/sport'
import Sportista from '../models/sportista'

export class siteController{

    getAllCountries = (req: express.Request, res: express.Response) => {
        Zemlja.find({}, (err, zemlje)=>{
            if(err) console.log(err);
            else res.json(zemlje);
        })
    }

    getAllMedals = (req: express.Request, res: express.Response) => {
        Medalje.find({}, (err, medalje)=>{
            if(err) console.log(err);
            else res.json(medalje);
        })
    }

    getAllSports = (req: express.Request, res: express.Response) => {
        Sport.find({}, (err, sportovi)=>{
            if(err) console.log(err);
            else res.json(sportovi);
        })
    }

    getAllSportists = (req: express.Request, res: express.Response) => {
        Sportista.find({}, (err, sportisti)=>{
            if(err) console.log(err);
            else res.json(sportisti);
        })
    }

}
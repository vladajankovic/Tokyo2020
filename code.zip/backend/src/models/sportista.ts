import mongoose from 'mongoose'

const Schema = mongoose.Schema;

const Sportista = new Schema(
    {
        ime:{
            type:String
        },
        prezime:{
            type:String
        },
        pol:{
            type:String
        },
        drzava:{
            type:String
        },
        sport:{
            type:String
        },
        disciplina:{
            type:String
        },
        tim:{
            type:Boolean
        },
        osvojio:{
            type:String
        }
    }
);

export default mongoose.model("Sportista", Sportista, 'sportisti');
import mongoose from 'mongoose'

const Schema = mongoose.Schema;

const Takmicenje = new Schema(
    {
        sport:{
            type:String
        },
        disciplina:{
            type:String
        },
        pol:{
            type:String
        },
        datumPocetka:{
            type:String
        },
        vremePocetka:{
            type:String
        },
        lokacija:{
            type:String
        },
        vrsta:{
            type:String
        },
        takmicari:{
            type:Array
        },
        delegati:{
            type:Array
        },
        brojUcesnika:{
            type:String
        },
        formatRez:{
            type:String
        },
        brojRundi:{
            type:Number
        },
        zavrseno:{
            type:Boolean
        },
        grupnafaza:{
            type:Array
        },
        osminafinala:{
            type:Array
        },
        cetvrtfinale:{
            type:Array
        },
        polufinale:{
            type:Array
        },
        finale:{
            type:Array
        },

    }
)

export default mongoose.model("Takmicenje", Takmicenje, 'takmicenja')
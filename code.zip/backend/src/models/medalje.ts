import mongoose from 'mongoose'

const Schema = mongoose.Schema;

const Medalje = new Schema(
    {
        naziv:{
            type:String
        },
        z:{
            type:Number
        },
        s:{
            type:Number
        },
        b:{
            type:Number
        },
        u:{
            type:Number
        }
    }
)

export default mongoose.model("Medalje", Medalje, 'medalje');
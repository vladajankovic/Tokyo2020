import mongoose from 'mongoose'

const Schema = mongoose.Schema;

const Rekord = new Schema(
    {
        disciplina:{
            type:String
        },
        rekord:{
            type:String
        },
        sportista:{
            type:String
        },
        nacionalnost:{
            type:String
        },
        mesto:{
            type:String
        },
        godina:{
            type:String
        }
    }
)

export default mongoose.model("Rekord", Rekord, 'rekordi')
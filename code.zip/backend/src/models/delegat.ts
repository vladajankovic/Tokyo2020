import mongoose from 'mongoose';

const Schema = mongoose.Schema;

const Delegat = new Schema(
    {
        korisnicko_ime:{
            type:String
        },
        ime:{
            type:String
        },
        prezime:{
            type:String
        },
        nadgledanja:{
            type:Array
        }
    }
)

export default mongoose.model("Delegat", Delegat, 'delegati');
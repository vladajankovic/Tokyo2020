import express from 'express'
import { organizatorController } from '../controllers/organizator.controller';

const organizatorRouter = express.Router();

organizatorRouter.route('/getPendingUsers').get(
    (req, res) => new organizatorController().getPendingUsers(req, res)
)
organizatorRouter.route('/getRecords').get(
    (req, res) => new organizatorController().getRecords(req, res)
)
organizatorRouter.route('/getAllTeams').get(
    (req, res) => new organizatorController().getAllTeams(req, res)
)
organizatorRouter.route('/getAllDelegats').get(
    (req, res) => new organizatorController().getAllDelegats(req, res)
)
organizatorRouter.route('/getAllTakmicenja').get(
    (req, res) => new organizatorController().getAllTakmicenja(req, res)
)
organizatorRouter.route('/remove').post(
    (req, res) => new organizatorController().remove(req, res)
)
organizatorRouter.route('/allowRequest').post(
    (req, res) => new organizatorController().allowRequest(req, res)
)
organizatorRouter.route('/registrujSport').post(
    (req, res) => new organizatorController().registrujSport(req, res)
)
organizatorRouter.route('/registrujTakmicenje').post(
    (req, res) => new organizatorController().registrujTakmicenje(req, res)
)
organizatorRouter.route('/proveri').post(
    (req, res) => new organizatorController().proveri(req, res)
)

export default organizatorRouter;
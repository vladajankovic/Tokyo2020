import { Component, OnInit } from '@angular/core';
import { Korisnik } from '../models/korisnik';
import { OrganizatorService } from '../organizator.service';

@Component({
  selector: 'app-zahteviregistracija',
  templateUrl: './zahteviregistracija.component.html',
  styleUrls: ['./zahteviregistracija.component.css']
})
export class ZahteviregistracijaComponent implements OnInit {

  constructor(private userService: OrganizatorService) { }

  ngOnInit(): void {
    this.userService.getAllPendingUsers().subscribe((k:Korisnik[])=>{
      this.korisnici = k.sort((a, b)=>{
        if(a.nacionalnost>b.nacionalnost) return 1;
        else if(a.nacionalnost<b.nacionalnost) return -1;
        else{
          if(a.tip_korisnika>b.tip_korisnika) return 1;
          else if(a.tip_korisnika<b.tip_korisnika) return -1;
          else return 0;
        }
      });
    })
  }

  korisnici: Korisnik[];

  odbij(username){
    this.userService.odbij(username).subscribe(poruka=>{
      if(poruka['message']=='removed'){
        window.location.reload()
      }
      else{
        alert('Greska');
      }
    })
  }

  odobri(username, nacionalnost, tip, ime, prezime){
    this.userService.odobri(username, nacionalnost, tip, ime, prezime).subscribe(poruka=>{
      if(poruka['msg']=='ok'){
        window.location.reload()
      }
      else{
        alert('Greska');
      }
    })
  }

}

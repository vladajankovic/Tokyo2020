import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrijavisportistuComponent } from './prijavisportistu.component';

describe('PrijavisportistuComponent', () => {
  let component: PrijavisportistuComponent;
  let fixture: ComponentFixture<PrijavisportistuComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrijavisportistuComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrijavisportistuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

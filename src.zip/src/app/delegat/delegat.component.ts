import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DelegatService } from '../delegat.service';
import { Delegat } from '../models/delegat';
import { Korisnik } from '../models/korisnik';

@Component({
  selector: 'app-delegat',
  templateUrl: './delegat.component.html',
  styleUrls: ['./delegat.component.css']
})
export class DelegatComponent implements OnInit {

  constructor(private userService:DelegatService, private ruter:Router) { }

  ngOnInit(): void {
    this.user=JSON.parse(localStorage.getItem('ulogovan'));
    if(this.user.tip_korisnika != 'delegat_takmicenja'){
      this.ruter.navigate([''])
    }
    this.userService.dohvatiSebe(this.user.korisnicko_ime).subscribe((d:Delegat)=>{
      this.delegat=d;
      this.delegat.nadgledanja.forEach(n=>{
        this.userService.dohvatiTakmicenje(n.sport, n.disciplina, n.pol).subscribe(t=>{
          this.listaTakmicenja.push(t);
          if(this.prikazanoTakmicenje==null){
            this.odabranoTakmicenje(this.listaTakmicenja[0]._id)
          }
        })
      })
    })
  }

  user: Korisnik;
  delegat:Delegat;
  listaTakmicenja:any[]=[];
  prikazanoTakmicenje:any=null;

  datum:string;
  vreme:string;
  mesto:string;
  setdvm:boolean=false;
  start:boolean=false;
  ponovi:boolean=false;
  zavrsi:boolean=false;
  showrez:boolean=false;
  tie:number[]=[];
  fin:boolean=false;
  tenis:boolean=false;
  ekipno:boolean=false;

  finale:any[]=[];
  polufinale:any[]=[];
  cetvrtfinale:any[]=[];
  osminafinala:any[]=[];
  formrez:any[]=[];

  odabranoTakmicenje(id){
    this.fin= this.tenis= this.ekipno= false;
    this.showrez=false;
    this.listaTakmicenja.forEach(t=>{
      if(t._id==id) this.prikazanoTakmicenje=t;
    })
    console.log(this.prikazanoTakmicenje)
    if(this.prikazanoTakmicenje.datumPocetka==''||this.prikazanoTakmicenje.vremePocetka==''||this.prikazanoTakmicenje.mesto==''){
      this.setdvm=true;
      this.start=false;
    }
    else{
      this.datum=this.prikazanoTakmicenje.datumPocetka;
      this.vreme=this.prikazanoTakmicenje.vremePocetka;
      this.mesto=this.prikazanoTakmicenje.lokacija;
      this.setdvm=false;
      this.start=true;
    }
    if(this.prikazanoTakmicenje.zavrseno==true){
      this.setdvm=this.start=this.ponovi=this.zavrsi=false;
      this.r1= this.r2= this.r3= this.r4= this.r5= this.r6= false
      this.showrez=true; this.best=true;
    }
    this.formrez=[];
    this.runda1=[];
    this.runda2=[];
    this.runda3=[];
    this.runda4=[];
    this.runda5=[];
    this.runda6=[];
    if(this.prikazanoTakmicenje.formatRez=='2:X'){
      for(let i = 0; i<2; i++){
        this.formrez.push('2:'+i);
        this.formrez.push(i+':2');
      }
    }
    if(this.prikazanoTakmicenje.formatRez=='3:X'){
      for(let i = 0; i<3; i++){
        this.formrez.push('3:'+i);
        this.formrez.push(i+':3');
      }
    }
    let tmp = this.prikazanoTakmicenje.brojUcesnika.split(',', 2)[1];
    if(tmp=='finale'){
      this.fin=true;
      let rezultati:{s:string, r:string, i:boolean, m:number}[] = [];
      this.prikazanoTakmicenje.takmicari.forEach(t=>{
        if(t.i) rezultati.push({s:t.ime+' '+t.prezime, r:'', i:false, m:0})
        else rezultati.push({s:t.drzava, r:'', i:false, m:0})
      })
      console.log(rezultati);
      if(this.prikazanoTakmicenje.finale.length==0){
        rezultati.forEach(r=>{
          this.prikazanoTakmicenje.finale.push(r);
          this.userService.upisiRezultat(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, r).subscribe();
        })
      }
    }
    else if(tmp=='tenis'){
      this.tenis=true;
      if(this.prikazanoTakmicenje.osminafinala.length!=0){
        this.osminafinala=this.prikazanoTakmicenje.osminafinala
      }
      if(this.prikazanoTakmicenje.cetvrtfinale.length!=0){
        this.cetvrtfinale=this.prikazanoTakmicenje.cetvrtfinale
      }
      if(this.prikazanoTakmicenje.polufinale.length!=0){
        this.polufinale=this.prikazanoTakmicenje.polufinale
      }
      if(this.prikazanoTakmicenje.finale.length!=0){
        this.finale=this.prikazanoTakmicenje.finale
      }
    }
    else{
      this.ekipno=true;
    }

  }

  /////////////////////////////////////////////////////////////Runde3/////////////////////////////////////////////////////////

  r1:boolean = false;
  r2:boolean = false;
  r3:boolean = false;
  r4:boolean = false;
  r5:boolean = false;
  r6:boolean = false;
  best:boolean=false;
  runda1:string[]=[];
  runda2:string[]=[];
  runda3:string[]=[];
  runda4:string[]=[];
  runda5:string[]=[];
  runda6:string[]=[];

  krajRunde(){
    if(this.r1==false){
      if(this.runda1.length<this.prikazanoTakmicenje.takmicari.length) return;
      this.r1=true;
      return;
    }
    else if(this.r2==false){
      if(this.runda2.length<this.prikazanoTakmicenje.takmicari.length) return;
      this.r2=true;
      return;
    }
    else if(this.r3==false){
      if(this.runda3.length<this.prikazanoTakmicenje.takmicari.length) return;
      this.r3=true;
      this.start=false;
      for(let i = 0; i<this.prikazanoTakmicenje.finale.length; i++){
        let max = parseInt(this.runda1[i]);
        if(parseInt(this.runda2[i])>max) max=parseInt(this.runda2[i]);
        if(parseInt(this.runda3[i])>max) max=parseInt(this.runda3[i]);
        this.prikazanoTakmicenje.finale[i].r=max.toString();
      }
      this.best=true;
      this.prikazanoTakmicenje.finale.sort((a, b)=>{
        if(parseInt(a.r)>parseInt(b.r)) return -1;
        else if(parseInt(a.r)<parseInt(b.r)) return 1;
        else return 0;
      })
      console.log(this.prikazanoTakmicenje.finale)
      this.prikazanoTakmicenje.finale[0].m=1;
      this.prikazanoTakmicenje.finale[0].i=true;
      for(let i = 1; i<this.prikazanoTakmicenje.finale.length; i++){
        if(parseInt(this.prikazanoTakmicenje.finale[i].r)<parseInt(this.prikazanoTakmicenje.finale[i-1].r)){
          this.prikazanoTakmicenje.finale[i].m=i+1;
          this.prikazanoTakmicenje.finale[i].i=true;
        }
        else{
          this.prikazanoTakmicenje.finale[i].m=i;
          this.prikazanoTakmicenje.finale[i-1].i=false;
          this.tie.push(i);
        }
      }
      if(this.tie.length>0) {this.ponovi=true; this.zavrsi=false;}
      else {this.ponovi=false; this.zavrsi=true;}
      this.showrez=true;
    }
  }

  kr6(){
    if(this.r1==false){
      if(this.runda1.length<this.prikazanoTakmicenje.takmicari.length) return;
      this.r1=true;
      return;
    }
    else if(this.r2==false){
      if(this.runda2.length<this.prikazanoTakmicenje.takmicari.length) return;
      this.r2=true;
      return;
    }
    if(this.r3==false){
      if(this.runda3.length<this.prikazanoTakmicenje.takmicari.length) return;
      this.r3=true;
      return;
    }
    else if(this.r4==false){
      if(this.runda4.length<this.prikazanoTakmicenje.takmicari.length) return;
      this.r4=true;
      return;
    }
    if(this.r5==false){
      if(this.runda5.length<this.prikazanoTakmicenje.takmicari.length) return;
      this.r5=true;
      return;
    }if(this.r6==false){
      if(this.runda1.length<this.prikazanoTakmicenje.takmicari.length) return;
      this.r6=true;
      this.start=false;
      for(let i = 0; i<this.prikazanoTakmicenje.finale.length; i++){
        let sum = parseInt(this.runda1[i]) + parseInt(this.runda2[i]) +parseInt(this.runda3[i]) +parseInt(this.runda4[i]) +parseInt(this.runda5[i]) +parseInt(this.runda6[i]);
        this.prikazanoTakmicenje.finale[i].r=sum.toString();
      }
      this.best=true;
      this.prikazanoTakmicenje.finale.sort((a, b)=>{
        if(parseInt(a.r)>parseInt(b.r)) return -1;
        else if(parseInt(a.r)<parseInt(b.r)) return 1;
        else return 0;
      })
      console.log(this.prikazanoTakmicenje.finale)
      this.prikazanoTakmicenje.finale[0].m=1;
      this.prikazanoTakmicenje.finale[0].i=true;
      for(let i = 1; i<this.prikazanoTakmicenje.finale.length; i++){
        if(parseInt(this.prikazanoTakmicenje.finale[i].r)<parseInt(this.prikazanoTakmicenje.finale[i-1].r)){
          this.prikazanoTakmicenje.finale[i].m=i+1;
          this.prikazanoTakmicenje.finale[i].i=true;
        }
        else{
          this.prikazanoTakmicenje.finale[i].m=i;
          this.prikazanoTakmicenje.finale[i-1].i=false;
          this.tie.push(i);
        }
      }
      if(this.tie.length>0) {this.ponovi=true; this.zavrsi=false;}
      else {this.ponovi=false; this.zavrsi=true;}
      this.showrez=true;
    }
    
  }

  krajTakm(){


  }

//////////////////////////////////////////////////////INDIVIDUALNA/TRKE TAKMICENJA///////////////////////////////////////////////////////////////////

  upisiSatnicu(){
    this.userService.upisiSatnicu(this.datum, this.vreme, this.mesto, this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol).subscribe(p=>{
      if(p['msg']=='ok') {this.setdvm=false; this.start=true;}
      else if(p['msg']=='zauzeto') alert("Zauzet termin");
    })
  }

  izmeri(){
    let neizmeren=false;
    this.prikazanoTakmicenje.finale.forEach(t=>{
      if(t.r=='') {
        neizmeren=true;
      }
    })
    if(neizmeren){
      alert("Nisu svi takmicari zavrsili");
      return;
    }

    this.prikazanoTakmicenje.finale.sort((a, b)=>{
      if(a.r>b.r) return 1;
      else if(a.r<b.r) return -1;
      else return 0;
    })
    console.log(this.prikazanoTakmicenje.finale)
    this.prikazanoTakmicenje.finale[0].m=1;
    this.prikazanoTakmicenje.finale[0].i=true;
    for(let i = 1; i<this.prikazanoTakmicenje.finale.length; i++){
      if(this.prikazanoTakmicenje.finale[i].r>this.prikazanoTakmicenje.finale[i-1].r){
        this.prikazanoTakmicenje.finale[i].m=i+1;
        this.prikazanoTakmicenje.finale[i].i=true;
      }
      else{
        this.prikazanoTakmicenje.finale[i].m=i;
        this.prikazanoTakmicenje.finale[i-1].i=false;
        this.tie.push(i);
      }
    }
    if(this.tie.length>0) {this.ponovi=true; this.zavrsi=false;}
    else {this.ponovi=false; this.zavrsi=true;}
    this.showrez=true;
  }

  ponoviMerenje(){
    for(let i = 0; i<this.tie.length; i++){
      if(this.tie[i]==-1) continue;
      let index1 = this.tie[i];
      let index2 = index1-1;
      if(this.prikazanoTakmicenje.finale[index1].r>this.prikazanoTakmicenje.finale[index2].r){
        this.prikazanoTakmicenje.finale[index1].m++;
        this.prikazanoTakmicenje.finale[index1].i=this.prikazanoTakmicenje.finale[index2].i=true;
        this.tie[i]=-1;
      }
      else if(this.prikazanoTakmicenje.finale[index1].r<this.prikazanoTakmicenje.finale[index2].r){
        this.prikazanoTakmicenje.finale[index2].m++;
        this.prikazanoTakmicenje.finale[index1].i=this.prikazanoTakmicenje.finale[index2].i=true;
        this.tie[i]=-1;
      }
      else{
        alert('Ponovo je nereseno')
        return;
      }
    }
    let flag = true;
    this.tie.forEach(n=>{
      if(n != -1) flag=false;
    })
    if(flag){
      this.ponovi=false; this.zavrsi=true;
    }

  }

  zavrsiTakmicenje(){
    this.prikazanoTakmicenje.finale.sort((a, b)=>{
      if(a.m>b.m) return 1;
      else if(a.m<b.m) return -1;
      else return 0;
    })
    let rezultati:{s:string, r:string, i:boolean, m:number}[] = this.prikazanoTakmicenje.finale;
    console.log(rezultati);
    this.userService.setRezultat(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, rezultati).subscribe(s=>{
      for(let i = 0; i<3; i++){
        if(this.prikazanoTakmicenje.finale[i]){
          let ip = this.prikazanoTakmicenje.finale[i].s.split(' ', 2);
          this.prikazanoTakmicenje.takmicari.forEach(t=>{
            if(t.ime==ip[0] && t.prezime==ip[1]){
              this.userService.dodeliMedalju(t.ime, t.prezime, t.pol, t.drzava, t.sport, t.disciplina, i+1).subscribe(()=>{
              })
            }
            if(t.drzava==ip[0]){
              t.tim.forEach(s=>{
                this.userService.dodeliMedalju(s.ime, s.prezime, s.pol, s.drzava, s.sport, s.disciplina, i+1).subscribe(()=>{
                })
              })
            }
          })
  
        }
      }
    })
    window.location.reload();
  }



  //////////////////////////////////////////////////////TENIS TAKMICENJA////////////////////////////////////////////////////


  tenis_alg(){
    if(!this.tenis) return;
    let par:any[]=[];
    let nepar:any[]=[];
    let lista:any[]=[];
    let broj = this.prikazanoTakmicenje.brojUcesnika.split(',', 2)[0];
    for(let i = 0; i<this.prikazanoTakmicenje.takmicari.length; i++){
      if(this.prikazanoTakmicenje.takmicari[i]){
        if(i%2==0){
          par.push(this.prikazanoTakmicenje.takmicari[i])
        }
        else{
          nepar.push(this.prikazanoTakmicenje.takmicari[i])
        }
      }
    }
    par.forEach(p=>lista.push(p));
    nepar.forEach(n=>lista.push(n));
    if(broj=='4'){
      if(this.prikazanoTakmicenje.polufinale.length==0){
        for(let i = 0; i<lista.length; i+=2){
          let mec:{datum:string, vreme:string, mesto:string, t1:any; t2:any, rez:string, start:boolean, kraj:boolean}={datum:'', vreme:'', mesto:'', t1:lista[i], t2:lista[i+1], rez:'', start:false, kraj:false};
          this.prikazanoTakmicenje.polufinale.push(mec);
        }
        this.userService.napraviPolufinale(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, this.prikazanoTakmicenje.polufinale).subscribe()
      }
    }
    else if(broj=='8'){
      if(this.prikazanoTakmicenje.cetvrtfinale.length==0){
        for(let i = 0; i<lista.length; i+=2){
          let mec:{datum:string, vreme:string, mesto:string, t1:any; t2:any, rez:string, start:boolean, kraj:boolean}={datum:'', vreme:'', mesto:'', t1:lista[i], t2:lista[i+1], rez:'', start:false, kraj:false};
          this.prikazanoTakmicenje.cetvrtfinale.push(mec);
        }
        this.userService.napraviCetvrtfinale(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, this.prikazanoTakmicenje.cetvrtfinale).subscribe()
      }
    }
    else if(broj=='16'){
      if(this.prikazanoTakmicenje.osminafinala.length==0){
        for(let i = 0; i<lista.length; i+=2){
          let mec:{datum:string, vreme:string, mesto:string, t1:any; t2:any, rez:string, start:boolean, kraj:boolean}={datum:'', vreme:'', mesto:'', t1:lista[i], t2:lista[i+1], rez:'', start:false, kraj:false};
          this.prikazanoTakmicenje.osminafinala.push(mec);
        }
        this.userService.napraviOsminafinala(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, this.prikazanoTakmicenje.osminafinala).subscribe()
      }
    }
  }

  upisiosm(datum, vreme, mesto, index){
    if(datum==''||vreme==''||mesto=='') return;
    this.prikazanoTakmicenje.osminafinala[index].start=true;
  }

  upisicet(datum, vreme, mesto, index){
    if(datum==''||vreme==''||mesto=='') return;
    this.prikazanoTakmicenje.cetvrtfinale[index].start=true;
  }

  upisipolu(datum, vreme, mesto, index){
    if(datum==''||vreme==''||mesto=='') return;
    this.prikazanoTakmicenje.polufinale[index].start=true;
  }

  upisifinale(datum, vreme, mesto, index){
    if(datum==''||vreme==''||mesto=='') return;
    this.prikazanoTakmicenje.finale[index].start=true;
  }

  zavrsiMecOsm(rez, index){
    if(rez=='') return;
    this.prikazanoTakmicenje.osminafinala[index].kraj=true;
    this.userService.napraviOsminafinala(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, this.prikazanoTakmicenje.osminafinala).subscribe(()=>{
      let flag = false;
      this.prikazanoTakmicenje.osminafinala.forEach(c=>{
        if(c.kraj==false) flag = true;
      })
      if(flag==false){
        let lista:any[]=[];
        this.prikazanoTakmicenje.osminafinala.forEach(c=>{
          let r = c.rez.split(':', 2);
          if(r[0]>r[1]) lista.push(c.t1)
          else lista.push(c.t2);
        })
        for(let i = 0; i<lista.length; i+=2){
          let mec:{datum:string, vreme:string, mesto:string, t1:any; t2:any, rez:string, start:boolean, kraj:boolean}={datum:'', vreme:'', mesto:'', t1:lista[i], t2:lista[i+1], rez:'', start:false, kraj:false};
          this.prikazanoTakmicenje.cetvrtfinale.push(mec);
        }
        this.userService.napraviCetvrtfinale(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, this.prikazanoTakmicenje.polufinale).subscribe()
        window.location.reload();
      }
    })
  }

  zavrsiMecCet(rez, index){
    if(rez=='') return;
    this.prikazanoTakmicenje.cetvrtfinale[index].kraj=true;
    this.userService.napraviCetvrtfinale(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, this.prikazanoTakmicenje.cetvrtfinale).subscribe(()=>{
      let flag = false;
      this.prikazanoTakmicenje.cetvrtfinale.forEach(c=>{
        if(c.kraj==false) flag = true;
      })
      if(flag==false){
        let lista:any[]=[];
        this.prikazanoTakmicenje.cetvrtfinale.forEach(c=>{
          let r = c.rez.split(':', 2);
          if(r[0]>r[1]) lista.push(c.t1)
          else lista.push(c.t2);
        })
        for(let i = 0; i<lista.length; i+=2){
          let mec:{datum:string, vreme:string, mesto:string, t1:any; t2:any, rez:string, start:boolean, kraj:boolean}={datum:'', vreme:'', mesto:'', t1:lista[i], t2:lista[i+1], rez:'', start:false, kraj:false};
          this.prikazanoTakmicenje.polufinale.push(mec);
        }
        this.userService.napraviPolufinale(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, this.prikazanoTakmicenje.polufinale).subscribe()
        window.location.reload();
      }
    })
  }

  zavrsiMecPolu(rez, index){
    if(rez=='') return;
    this.prikazanoTakmicenje.polufinale[index].kraj=true;
    this.userService.napraviPolufinale(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, this.prikazanoTakmicenje.polufinale).subscribe(()=>{
      let flag = false;
      this.prikazanoTakmicenje.polufinale.forEach(c=>{
        if(c.kraj==false) flag = true;
      })
      if(flag==false){
        let lista:any[]=[];
        let tmp:any[]=[];
        this.prikazanoTakmicenje.polufinale.forEach(c=>{
          let r = c.rez.split(':', 2);
          if(r[0]>r[1]) {
            lista.push(c.t1)
            tmp.push(c.t2);
          }
          else {
            lista.push(c.t2)
            tmp.push(c.t1);
          }
        })
        tmp.forEach(t=>lista.push(t))
        for(let i = 0; i<lista.length; i+=2){
          let mec:{datum:string, vreme:string, mesto:string, t1:any; t2:any, rez:string, start:boolean, kraj:boolean}={datum:'', vreme:'', mesto:'', t1:lista[i], t2:lista[i+1], rez:'', start:false, kraj:false};
          this.prikazanoTakmicenje.finale.push(mec);
        }
        this.userService.napraviFinale(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, this.prikazanoTakmicenje.finale).subscribe()
        window.location.reload();
      }
    })
  }

  zavrsiMecFinale(rez, index){
    if(rez=='') return;
    this.prikazanoTakmicenje.finale[index].kraj=true;
    this.userService.napraviFinale(this.prikazanoTakmicenje.sport, this.prikazanoTakmicenje.disciplina, this.prikazanoTakmicenje.pol, this.prikazanoTakmicenje.finale).subscribe(()=>{
      let flag = false;
      this.prikazanoTakmicenje.finale.forEach(c=>{
        if(c.kraj==false) flag = true;
      })
      if(flag==false){
        let lista:any[]=[];
        this.prikazanoTakmicenje.finale.forEach(c=>{
          let r = c.rez.split(':', 2);
          if(r[0]>r[1]) {
            lista.push(c.t1)
            lista.push(c.t2);
          }
          else {
            lista.push(c.t2)
            lista.push(c.t1);
          }
        })
        for(let i = 0; i<3; i++){
          let l = lista[i];
          console.log(l)
          this.userService.dodeliMedalju(l.ime, l.prezime, l.pol, l.drzava, l.sport, l.disciplina, i+1).subscribe(()=>{});
        }
      }
    })
  }

  //////////////////////////////////////////////////////////EKIPNO////////////////////////////////////////////////////

  raspored_alg(){
    
  }

}


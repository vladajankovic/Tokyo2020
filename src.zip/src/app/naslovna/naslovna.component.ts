import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-naslovna',
  templateUrl: './naslovna.component.html',
  styleUrls: ['./naslovna.component.css']
})
export class NaslovnaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

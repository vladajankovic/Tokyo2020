export class Delegat{
    korisnicko_ime:string;
    ime:string;
    prezime:string;
    nadgledanja:Array<any>
}
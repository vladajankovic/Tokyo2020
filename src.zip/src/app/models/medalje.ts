export class Medalje{
    naziv: string;
    z:number;
    s:number;
    b:number;
    u:number;
    rang:number;
}
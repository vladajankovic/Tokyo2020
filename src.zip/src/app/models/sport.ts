export class Sport{
    sport:string;
    disciplina:string;
    vrsta:string;
    brojIgraca:string;
}
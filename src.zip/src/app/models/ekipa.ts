import { Sportista } from "./sportista";

export class Ekipa{
    sport:string;
    disciplina:string;
    drzava:string;
    pol:string;
    tim:Array<Sportista>
}
export class Takmicenje{
    sport:string;
    disciplina:string;
    pol:string;
}
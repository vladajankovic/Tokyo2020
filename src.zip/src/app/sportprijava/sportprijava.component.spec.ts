import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SportprijavaComponent } from './sportprijava.component';

describe('SportprijavaComponent', () => {
  let component: SportprijavaComponent;
  let fixture: ComponentFixture<SportprijavaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SportprijavaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SportprijavaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

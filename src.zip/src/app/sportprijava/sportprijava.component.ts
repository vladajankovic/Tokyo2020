import { Component, OnInit } from '@angular/core';
import { OrganizatorService } from '../organizator.service';

@Component({
  selector: 'app-sportprijava',
  templateUrl: './sportprijava.component.html',
  styleUrls: ['./sportprijava.component.css']
})
export class SportprijavaComponent implements OnInit {

  constructor(private userService: OrganizatorService) { }

  ngOnInit(): void {
  }

  sport:string='';
  disciplina:string='';
  vrsta:string='individualno';
  brojIgraca:string='';
  min:number=2;
  max:number=2;

  obrisi(){
    window.location.reload();
  }

  registruj(){
    if(this.sport==''||this.disciplina=='') {alert("Unesi sve podatke!"); return;}
    if(this.vrsta=='ekipno'){
      if(this.min>this.max) {alert("Min ne sme biti veci od max!"); return;}
      else if(this.min==this.max) this.brojIgraca=this.min.toString();
      else this.brojIgraca = this.min+'/'+this.max;
    }
    this.userService.registrujSport(this.sport, this.disciplina, this.vrsta, this.brojIgraca).subscribe(poruka=>{
      if(poruka['msg']=='postoji') alert('Sport i disciplina su vec registrovani');
      else if(poruka['msg']=='ok'){
      }
      else{
        alert('Greska')
      }
    })

  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Korisnik } from '../models/korisnik';

@Component({
  selector: 'app-mainpage',
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css']
})
export class MainpageComponent implements OnInit {

  constructor( private ruter:Router) { }

  ngOnInit(): void {
    if(localStorage.getItem('ulogovan')){
      this.ulogovan=true;
      this.user=JSON.parse(localStorage.getItem('ulogovan'));
    }
    else this.ulogovan=false;
  }

  ulogovan:boolean=false;
  user:Korisnik;

  pag_reset(){
    localStorage.setItem('paginacija', '10');
    localStorage.removeItem('filter');
  }

  odjava(){
    localStorage.removeItem('ulogovan');
    window.location.reload();
  }

  passchange(){
    this.ruter.navigate(['promenalozinke'])
  }

  korisnikportal(){
    if(this.ulogovan){
      let u:Korisnik = JSON.parse(localStorage.getItem('ulogovan'));
      if(u.tip_korisnika == 'delegat_vodja') this.ruter.navigate(['korisnik/vodja']);
      else if(u.tip_korisnika == 'delegat_takmicenja') this.ruter.navigate(['korisnik/delegat']);
      else this.ruter.navigate(['korisnik/organizator']);
    }
    else{
      this.ruter.navigate(['login'])
    }
  }

}

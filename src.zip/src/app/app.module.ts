import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { ZemljeComponent } from './zemlje/zemlje.component';
import { MedaljeComponent } from './medalje/medalje.component';
import { SportistiComponent } from './sportisti/sportisti.component';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { NaslovnaComponent } from './naslovna/naslovna.component';
import { PendingComponent } from './pending/pending.component';
import { KorisnikComponent } from './korisnik/korisnik.component';
import { VodjaComponent } from './vodja/vodja.component';
import { DelegatComponent } from './delegat/delegat.component';
import { OrganizatorComponent } from './organizator/organizator.component';
import { PromenalozinkeComponent } from './promenalozinke/promenalozinke.component';
import { PrijavisportistuComponent } from './prijavisportistu/prijavisportistu.component';
import { PregledsportistaComponent } from './pregledsportista/pregledsportista.component';
import { ZahteviregistracijaComponent } from './zahteviregistracija/zahteviregistracija.component';
import { SportprijavaComponent } from './sportprijava/sportprijava.component';
import { TakmicenjeprijavaComponent } from './takmicenjeprijava/takmicenjeprijava.component';
import { RekordiComponent } from './rekordi/rekordi.component';

@NgModule({
  declarations: [
    AppComponent,
    MainpageComponent,
    ZemljeComponent,
    MedaljeComponent,
    SportistiComponent,
    LoginComponent,
    RegisterComponent,
    NaslovnaComponent,
    PendingComponent,
    KorisnikComponent,
    VodjaComponent,
    DelegatComponent,
    OrganizatorComponent,
    PromenalozinkeComponent,
    PrijavisportistuComponent,
    PregledsportistaComponent,
    ZahteviregistracijaComponent,
    SportprijavaComponent,
    TakmicenjeprijavaComponent,
    RekordiComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, OnInit } from '@angular/core';
import { Korisnik } from '../models/korisnik';
import { Sport } from '../models/sport';
import { Sportista } from '../models/sportista';
import { SiteService } from '../site.service';
import { VodjaService } from '../vodja.service';

@Component({
  selector: 'app-pregledsportista',
  templateUrl: './pregledsportista.component.html',
  styleUrls: ['./pregledsportista.component.css']
})
export class PregledsportistaComponent implements OnInit {

  constructor(private site: SiteService, private userService: VodjaService) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem('ulogovan'));
    this.site.getAllSports().subscribe((s: Sport[]) => {
      this.listaSportova = s;
      for (let i = 0; i < this.listaSportova.length; i++) {
        let flag = false;
        for (let j = 0; j < this.vrsteSportova.length; j++) {
          if (this.listaSportova[i].sport == this.vrsteSportova[j]) flag = true;
        }
        if (!flag) this.vrsteSportova.push(this.listaSportova[i].sport);
      }
      this.userService.getMyDelegation(this.user.nacionalnost).subscribe((s: Sportista[]) => {
        this.mojaDelegacija = s.sort((a, b)=>{
          if(a.ime>b.ime) return 1;
          else if(a.ime<b.ime) return -1;
          else return 0;
        });
        this.pregled();
      })
    })
    
    
  }

  user: Korisnik;
  mojaDelegacija: Sportista[];
  listaSportova: Sport[];
  vrsteSportova: string[] = [];
  bcsport:string;
  bcdisciplina:string;
  brojPoSportu: { sport: string; broj: number; }[]=[];
  brojPoDisciplini: { disciplina: string; broj: number; }[]=[];
  pregledSportista: Sportista[] = [];
  en1:boolean=false;
  en2:boolean=false;


  pregled(){
    this.en1=false;
    this.en2=false;
    this.bcsport=this.bcdisciplina='';
    for(let i = 0; i<this.vrsteSportova.length; i++){
      this.brojPoSportu[i] = {sport:this.vrsteSportova[i], broj:0}
    }
    let last:Sportista = null;
    for(let i = 0; i<this.mojaDelegacija.length; i++){
      if(last == null){
        for(let j = 0; j<this.brojPoSportu.length; j++){
          if(this.brojPoSportu[j].sport==this.mojaDelegacija[i].sport){ this.brojPoSportu[j].broj++; break;}
        }
        last = this.mojaDelegacija[i];
      }
      else if(last.ime == this.mojaDelegacija[i].ime && last.prezime == this.mojaDelegacija[i].prezime && last.pol == this.mojaDelegacija[i].pol) continue;
      else{
        for(let j = 0; j<this.brojPoSportu.length; j++){
          if(this.brojPoSportu[j].sport==this.mojaDelegacija[i].sport){ this.brojPoSportu[j].broj++; break;}
        }
        last = this.mojaDelegacija[i];
      }
    }
    let tmp:{ sport: string; broj: number; }[]=[];
    for(let i = 0; i<this.brojPoSportu.length; i++){
      if(this.brojPoSportu[i].broj != 0) tmp.push(this.brojPoSportu[i]);
    }
    this.brojPoSportu=tmp;
    console.log(this.brojPoSportu);
  }

  sport_pregled(sport){
    this.en1 = true;
    this.en2 = false;
    if(sport=='') sport = this.bcsport;
    else this.bcsport = sport;
    this.brojPoDisciplini=[]
    this.listaSportova.forEach((s)=>{
      if(s.sport==sport && s.disciplina != ''){
        this.brojPoDisciplini.push({disciplina:s.disciplina, broj:0})
      }
    })
    console.log(this.brojPoDisciplini)
    if(this.brojPoDisciplini.length==0) this.disicplina_pregled('');
    else{
      this.mojaDelegacija.forEach((d)=>{
        this.brojPoDisciplini.forEach((b)=>{
          if(d.disciplina==b.disciplina) b.broj++;
        })
      })
      let tmp:{ disciplina: string; broj: number; }[]=[];
      for(let i = 0; i<this.brojPoDisciplini.length; i++){
        if(this.brojPoDisciplini[i].broj != 0) tmp.push(this.brojPoDisciplini[i]);
      }
      this.brojPoDisciplini=tmp;
    }
  }

  disicplina_pregled(disciplina){
    this.bcdisciplina = disciplina;
    this.en1 = false;
    this.en2 = true;
    this.pregledSportista = []
    this.mojaDelegacija.forEach((d)=>{
      if(d.sport==this.bcsport && d.disciplina==disciplina){
        this.pregledSportista.push(d);
      }
    })
  }
}

import { Component, OnInit } from '@angular/core';
import { Zemlja } from 'src/app/models/zemlja';
import { SiteService } from '../site.service';

@Component({
  selector: 'app-zemlje',
  templateUrl: './zemlje.component.html',
  styleUrls: ['./zemlje.component.css']
})
export class ZemljeComponent implements OnInit {

  constructor(private site: SiteService) { }

  ngOnInit(): void {
    this.site.getAllCountries().subscribe( (z:Zemlja[]) => {
      this.listaZemalja=z;
      this.page=1;
      this.paginacija=localStorage.getItem('paginacija')
      for(let i = 0; i<parseInt(this.paginacija); i++){
        this.prikazaneZemlje.push(this.listaZemalja[i])
      }
    })
  }

  listaZemalja: Zemlja[];
  prikazaneZemlje: Zemlja[]=[];
  page: number;
  paginacija:string;
  first=true;
  last=false;
  dummy: Zemlja = {naziv:'', brojSportista:null}

  sledZemlje(){
    if(this.last) return;
    this.first=false;
    this.page++;
    this.prikazaneZemlje=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.listaZemalja[i]) this.prikazaneZemlje.push(this.listaZemalja[i]);
      else this.prikazaneZemlje.push(this.dummy);
    }
    
    if(parseInt(this.paginacija)*(this.page)>this.listaZemalja.length) this.last=true;
  }

  prethZemlje(){
    if(this.first) return;
    this.last=false;
    this.page--;
    this.prikazaneZemlje=[]
    for(let i = parseInt(this.paginacija)*(this.page-1); i<parseInt(this.paginacija)*this.page; i++){
      if(this.listaZemalja[i]) this.prikazaneZemlje.push(this.listaZemalja[i]);
      else this.prikazaneZemlje.push(this.dummy);
    }
    if(this.page==1) this.first=true;
  }

  reset(){
    this.page=1;
    localStorage.setItem('paginacija', this.paginacija);
    window.location.reload();
  }

}

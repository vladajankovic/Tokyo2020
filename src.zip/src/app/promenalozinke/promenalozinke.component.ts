import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Korisnik } from '../models/korisnik';
import { UserService } from '../user.service';

@Component({
  selector: 'app-promenalozinke',
  templateUrl: './promenalozinke.component.html',
  styleUrls: ['./promenalozinke.component.css']
})
export class PromenalozinkeComponent implements OnInit {

  constructor(private userService:UserService, private ruter:Router) { }

  ngOnInit(): void {
    this.user = JSON.parse(localStorage.getItem('ulogovan'))
  }

  user: Korisnik;
  oldpass:string;
  newpass:string;
  errold:string = '';
  errsame:string = '';
  flag1:boolean = false;
  flag2:boolean = false;
  exit5: boolean = false;
  lenflag: boolean = true;
  fourinarowflag: boolean = true;
  firstletterflag: boolean = true;
  nbrojevaflag: boolean = true;
  nspecflag: boolean = true;
  nmalihflag: boolean = true;
  nvelikflag: boolean = true;

  promeni(){

    if(this.user.lozinka != this.oldpass) {
      this.errold = 'Pogresno ste uneli staru lozinku!'
      this.flag1=true;
    }
    else{
      this.errold='';
      this.flag1=false;
    }
    if(this.oldpass==this.newpass){
      this.errsame='Nova lozinka se mora razlikovati od stare!'
      this.flag2=true;
    }
    else{
      this.errsame=''
      this.flag2=false;
    }

    if(this.flag1 || this.flag2 || this.exit5) return;
    
    this.userService.changepass(this.user.korisnicko_ime, this.newpass).subscribe(poruka=>{
      if(poruka['message']='ok'){
        alert('Lozinka je uspesno promenjena.\nPovratak na stranicu za prijavljivanje.');
        localStorage.removeItem('ulogovan');
        this.ruter.navigate(['login']);
      }
    })

  }

  nazad(){
    if(localStorage.getItem('back')){
      let url = localStorage.getItem('back')
      localStorage.removeItem('back')
      this.ruter.navigate([url]);
    }
    else this.ruter.navigate([''])
  }

  passpatern() {
    this.exit5 = false;
    let dcnt = 0; let scnt = 0; let mcnt = 0; let vcnt = 0;
    this.lenflag = this.fourinarowflag = this.firstletterflag = false;
    this.nbrojevaflag = this.nspecflag = this.nmalihflag = this.nvelikflag = false;
    if (this.newpass.length > 12 || this.newpass.length < 8) this.lenflag = this.exit5 = true;

    let reg = /(.)\1\1\1/
    if (reg.test(this.newpass)) this.fourinarowflag = this.exit5 = true;

    reg = /^[a-zA-Z].*/
    if (!reg.test(this.newpass)) this.firstletterflag = this.exit5 = true;

    let dreg = /\d/; let sreg = /\W|_/; let mreg = /[a-z]/; let vreg = /[A-Z]/;
    for (let i = 0; i < this.newpass.length; i++) {
      if (dreg.test(this.newpass[i])) dcnt++;
      if (sreg.test(this.newpass[i])) scnt++;
      if (mreg.test(this.newpass[i])) mcnt++;
      if (vreg.test(this.newpass[i])) vcnt++;
    }
    if (dcnt < 2) this.nbrojevaflag = this.exit5 = true;
    if (scnt < 2) this.nspecflag = this.exit5 = true;
    if (mcnt < 3) this.nmalihflag = this.exit5 = true;
    if (vcnt < 1) this.nvelikflag = this.exit5 = true;

    if (this.newpass == '') {
      this.lenflag =this.fourinarowflag = this.firstletterflag = this.nbrojevaflag = true;
      this.nspecflag = this.nmalihflag = this.nvelikflag = true;
    }
  }

}

import express from 'express'
import Sportista from '../models/sportista';
import Korisnik from '../models/korisnik';

export class userController {

    login = (req: express.Request, res: express.Response) => {
        let username = req.body.username;
        let password = req.body.password;

        Korisnik.findOne({ 'korisnicko_ime': username, 'lozinka': password }, (err, user) => {
            if (err) console.log(err);
            else res.json(user);
        })

    }

    register = (req: express.Request, res: express.Response) => {
        const korisnik = new Korisnik(req.body)
        console.log(korisnik)
        korisnik.save().then(korisnik => {
            res.status(200).json({ 'message': 'ok' })
        }).catch(err => {
            res.status(400).json(err)
        })


    }

    getVodju = (req: express.Request, res: express.Response) => {
        let zemlja = req.body.zemlja

        Korisnik.findOne({ 'nacionalnost': zemlja, 'tip_korisnika': 'delegat_vodja', 'odobren':1}, (err, user) => {
            if (err) console.log(err);
            else res.json(user);
        })

    }

    checkUsername = (req: express.Request, res: express.Response) => {
        let username = req.body.username

        Korisnik.findOne({ 'korisnicko_ime': username }, (err, user) => {
            if (err) console.log(err);
            else res.json(user);
        })

    }

    changepass = (req: express.Request, res: express.Response) => {
        let lozinka = req.body.lozinka
        let korisnicko_ime = req.body.korisnicko_ime

        Korisnik.findOne({ 'korisnicko_ime': korisnicko_ime }, (err, user) => {
            if (err) console.log(err);
            else {
                Korisnik.collection.updateOne({ 'korisnicko_ime': korisnicko_ime }, { $set: { 'lozinka': lozinka } });
                res.json({ 'message': 'ok' });
            }
        })

    }

    

}
import express from 'express'
import { siteController } from '../controllers/site.controller';

const siteRouter = express.Router();

siteRouter.route('/allCountries').get(
    (req, res) => new siteController().getAllCountries(req, res)
)

siteRouter.route('/allMedals').get(
    (req, res) => new siteController().getAllMedals(req, res)
)

siteRouter.route('/allSports').get(
    (req, res) => new siteController().getAllSports(req, res)
)

siteRouter.route('/allSportists').get(
    (req, res) => new siteController().getAllSportists(req, res)
)

export default siteRouter;
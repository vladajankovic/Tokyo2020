import express from 'express'
import { delegatController } from '../controllers/delegat.controller';

const delegatRouter = express.Router();

delegatRouter.route('/dohvatiSebe').post(
    (req, res)=> new delegatController().dohvatiSebe(req, res)
)
delegatRouter.route('/dohvatiTakmicenje').post(
    (req, res)=> new delegatController().dohvatiTakmicenje(req, res)
)
delegatRouter.route('/upisiSatnicu').post(
    (req, res)=> new delegatController().upisiSatnicu(req, res)
)
delegatRouter.route('/upisiRezultat').post(
    (req, res)=> new delegatController().upisiRezultat(req, res)
)
delegatRouter.route('/setRezultat').post(
    (req, res)=> new delegatController().setRezultat(req, res)
)
delegatRouter.route('/napraviFinale').post(
    (req, res)=> new delegatController().napraviFinale(req, res)
)
delegatRouter.route('/napraviPolufinale').post(
    (req, res)=> new delegatController().napraviPolufinale(req, res)
)
delegatRouter.route('/napraviCetvrtfinale').post(
    (req, res)=> new delegatController().napraviCetvrtfinale(req, res)
)
delegatRouter.route('/napraviOsminafinala').post(
    (req, res)=> new delegatController().napraviOsminafinala(req, res)
)
delegatRouter.route('/dodeliMedalju').post(
    (req, res)=> new delegatController().dodeliMedalju(req, res)
)
export default delegatRouter;
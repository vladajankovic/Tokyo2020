import express from 'express'
import { vodjaController } from '../controllers/vodja.controller';

const vodjaRouter = express.Router();

vodjaRouter.route('/getMyTeams').post(
    (req, res) => new vodjaController().getMyTeams(req, res)
)
vodjaRouter.route('/getMyDelegation').post(
    (req, res) => new vodjaController().getMyDelegation(req, res)
)
vodjaRouter.route('/proveriSportistu').post(
    (req, res) => new vodjaController().proveriSportistu(req, res)
)
vodjaRouter.route('/proveriSportistuD').post(
    (req, res) => new vodjaController().proveriSportistuD(req, res)
)
vodjaRouter.route('/prijaviSportistu').post(
    (req, res) => new vodjaController().prijaviSportistu(req, res)
)
vodjaRouter.route('/prijaviEkipu').post(
    (req, res) => new vodjaController().prijaviEkipu(req, res)
)

export default vodjaRouter
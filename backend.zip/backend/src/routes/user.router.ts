import express from 'express'
import { userController } from '../controllers/user.controller';

const userRouter = express.Router();

userRouter.route('/login').post(
    (req, res) => new userController().login(req, res)
)
userRouter.route('/register').post(
    (req, res) => new userController().register(req, res)
)
userRouter.route('/getVodju').post(
    (req, res) => new userController().getVodju(req, res)
)
userRouter.route('/checkUsername').post(
    (req, res) => new userController().checkUsername(req, res)
)
userRouter.route('/changepass').post(
    (req, res) => new userController().changepass(req, res)
)

export default userRouter;
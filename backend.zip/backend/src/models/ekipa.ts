import mongoose from 'mongoose';

const Schema = mongoose.Schema;

const Ekipa = new Schema(
    {
        sport:{
            type:String
        },
        disciplina:{
            type:String
        },
        drzava:{
            type:String
        },
        pol:{
            type:String
        },
        tim:{
            type:Array
        }
    }
)

export default mongoose.model("Ekipa", Ekipa, 'ekipe');
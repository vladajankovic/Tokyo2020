import mongoose from 'mongoose'

const Schema = mongoose.Schema;

const Sport = new Schema(
    {
        sport:{
            type:String
        },
        disciplina:{
            type:String
        },
        vrsta:{
            type:String
        },
        brojIgraca:{
            type:String
        }
    }
)

export default mongoose.model("Sport", Sport, 'sportovi');
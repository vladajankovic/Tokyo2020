import * as mongoose from 'mongoose'

const Schema = mongoose.Schema;

const Zemlja = new Schema(
    {
        naziv:{
            type:String
        },
        brojSportista:{
            type:Number
        }
    }
)

export default mongoose.model("Zemlja", Zemlja, 'zemlje');